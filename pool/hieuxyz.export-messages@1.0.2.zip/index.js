(function(e,t){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});function n(e){return typeof e==`string`?e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#39;`):e==null?``:String(e)}function r(e,t){if(typeof e!=`string`||!e)return``;if(e.startsWith(`attachment://`)){var n=e.slice(13),r=t?.find(function(e){return e.filename===n});if(r)return r.proxy_url||r.url}return e}function i(e,t){if(e){if(Array.isArray(e))return e.find(function(e){return e&&(e.id===t||e.roleId===t)});if(typeof e==`object`){var n=e;return n[t]?n[t]:Object.values(n).find(function(e){return e&&(e.id===t||e.roleId===t)})}}}function a(e){return e.colorString?e.colorString:typeof e.color==`number`&&e.color>0?`#${e.color.toString(16).padStart(6,`0`)}`:e.colorStrings?.primaryColor}function o(e,t){var n=valenced.discord.flux.Stores;if(t){var r=n.GuildRoleStore?.getRole?.(t,e);if(r?.name)return{name:r.name,color:a(r)};var o=n.GuildRoleStore?.getUnsafeMutableRoles?.(t),s=i(o,e);if(s?.name)return{name:s.name,color:a(s)};var c=n.GuildRoleStore?.getRoles?.(t),l=i(c,e);if(l?.name)return{name:l.name,color:a(l)};var u=n.GuildStore?.getGuild?.(t)?.roles,d=i(u,e);if(d?.name)return{name:d.name,color:a(d)}}var f=n.GuildStore?.getGuilds?.();if(f)for(var[p,m]of Object.entries(f)){var h=i(m.roles,e)||n.GuildRoleStore?.getRole?.(p,e)||i(n.GuildRoleStore?.getUnsafeMutableRoles?.(p),e)||i(n.GuildRoleStore?.getRoles?.(p),e);if(h?.name)return{name:h.name,color:a(h)}}}function s(e){if(e.embeds&&e.embeds.length>0){var t=e.embeds.find(function(e){return e.type===`poll_result`})||e.embeds[0];if(t?.fields&&t.fields.length>0){var n=function(e){var n=t.fields?.find(function(t){return t.name===e||t.rawName===e});return(n?.value??n?.rawValue??``).trim()},r=n(`poll_question_text`),i=n(`victor_answer_text`),a=n(`victor_answer_votes`),o=n(`total_votes`),s=n(`victor_answer_emoji_name`),c=n(`victor_answer_emoji_id`),l=n(`victor_answer_emoji_animated`)===`true`;if(r||i)return{question:r,victorText:i,victorVotes:a,totalVotes:o,emojiName:s||void 0,emojiId:c||void 0,emojiAnimated:l}}}if(e.poll){var u=function(e){var t=p.find(function(t){return t.id===e.answer_id})?.count??0;t>m&&(m=t,h=e)},d=e.poll.question?.text||``,f=e.poll.answers||[],p=e.poll.results?.answer_counts||[],m=-1,h=f[0];for(var g of f)u(g);var _=String(e.poll.results?.total_votes??p.reduce(function(e,t){return e+(t.count||0)},0));return{question:d,victorText:h?.poll_media?.text||``,victorVotes:m>=0?String(m):`0`,totalVotes:_,emojiName:h?.poll_media?.emoji?.name,emojiId:h?.poll_media?.emoji?.id,emojiAnimated:h?.poll_media?.emoji?.animated}}return null}function c(e,t=`f`){var n=Number.parseInt(e,10);if(Number.isNaN(n)||n<=0)return e;var r=/* @__PURE__ */ new Date(n*1e3),i=Date.now(),a=Math.round((n*1e3-i)/1e3);if(t===`R`){var o=new Intl.RelativeTimeFormat(void 0,{numeric:`auto`}),s=Math.abs(a);return s<60?o.format(a,`second`):s<3600?o.format(Math.round(a/60),`minute`):s<86400?o.format(Math.round(a/3600),`hour`):o.format(Math.round(a/86400),`day`)}return t===`t`?r.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`}):t===`T`?r.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`,second:`2-digit`}):t===`d`?r.toLocaleDateString():t===`D`?r.toLocaleDateString([],{day:`numeric`,month:`long`,year:`numeric`}):t===`F`?`${r.toLocaleDateString([],{weekday:`long`,day:`numeric`,month:`long`,year:`numeric`})} ${r.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})}`:`${r.toLocaleDateString([],{day:`numeric`,month:`long`,year:`numeric`})} ${r.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})}`}function l(e,t,r,i,a){if(!e)return``;var s=[],l=function(e){var t=s.length;return s.push(e),`\u0000TOK_${t}\u0000`},u=n(e),d=!!e.trim().match(/^(?:<(?:a)?:[a-zA-Z0-9_]+:\d+>\s*){1,5}$/);u=u.replace(/```(?:([a-zA-Z0-9_-]+)\n)?([\s\S]*?)```/g,function(e,t,n){return l(`<code class="chatlog__markdown-pre chatlog__markdown-pre--multiline${t?` language-${t}`:` nohighlight`}">${n.trim()}</code>`)}),u=u.replace(/`([^`\n]+)`/g,function(e,t){return l(`<code class="chatlog__markdown-pre chatlog__markdown-pre--inline">${t}</code>`)}),u=u.replace(/&lt;(a)?:([a-zA-Z0-9_]+):(\d+)&gt;/g,function(e,t,n,r){var i=`https://cdn.discordapp.com/emojis/${r}.${t?`gif`:`webp`}?size=64&quality=lossless`;return l(`<img class="chatlog__emoji${d?` chatlog__emoji--large`:``}" src="${i}" alt=":${n}:" title=":${n}:" loading="lazy" />`)}),u=u.replace(/(https?:\/\/[^\s<]+)/g,function(e,t){return l(`<a href="${t}" target="_blank" rel="noopener noreferrer">${t}</a>`)}),u=u.replace(/&lt;t:(\d+)(?::([tTdDfFR]))?&gt;/g,function(e,t,n){var r=c(t,n||`f`);return l(`<span class="chatlog__markdown-timestamp" title="${(/* @__PURE__ */ new Date(Number.parseInt(t,10)*1e3)).toLocaleString()}">${r}</span>`)}),u=u.replace(/&lt;@!?(\d+)&gt;/g,function(e,r){var i=t.get(r);if(!i){var a=valenced.discord.flux.Stores.UserStore?.getUser?.(r);a&&(i=a.globalName||a.username,t.set(r,i))}var o=i?`@${i}`:`@User (${r.slice(-4)})`;return l(`<span class="chatlog__markdown-mention" title="${n(i||r)}">${n(o)}</span>`)}),u=u.replace(/&lt;#(\d+)&gt;/g,function(e,t){var i=r.get(t);if(!i){var a=valenced.discord.flux.Stores.ChannelStore?.getChannel?.(t);a&&(i=a.name,r.set(t,i))}return l(`<span class="chatlog__markdown-mention">${n(i?`#${i}`:`#channel`)}</span>`)}),u=u.replace(/&lt;@&amp;(\w+)&gt;/g,function(e,t){var r=i?.get(t);return r||(r=o(t,a),r&&i&&i.set(t,r)),l(r?`<span class="chatlog__markdown-mention chatlog__markdown-mention--role"${r.color?` style="color: ${r.color};"`:``}>@${n(r.name)}</span>`:`<span class="chatlog__markdown-mention">@role</span>`)}),u=u.replace(/@everyone/g,function(){return l(`<span class="chatlog__markdown-mention">@everyone</span>`)}),u=u.replace(/@here/g,function(){return l(`<span class="chatlog__markdown-mention">@here</span>`)}),u=u.replace(/\|\|([\s\S]*?)\|\|/g,`<span class="chatlog__markdown-spoiler chatlog__markdown-spoiler--hidden" onclick="showSpoiler(event, this)">$1</span>`),u=u.replace(/^### (.*)$/gm,`<h3>$1</h3>`),u=u.replace(/^## (.*)$/gm,`<h2>$1</h2>`),u=u.replace(/^# (.*)$/gm,`<h1>$1</h1>`),u=u.replace(/^-# (.*)$/gm,`<div class="chatlog__markdown-subtext">$1</div>`),u=u.replace(/^&gt;&gt;&gt;\s*([\s\S]*)$/m,`<div class="chatlog__markdown-quote"><div class="chatlog__markdown-quote-border"></div><div class="chatlog__markdown-quote-content">$1</div></div>`),u=u.replace(/^&gt;\s?(.*)$/gm,`<div class="chatlog__markdown-quote"><div class="chatlog__markdown-quote-border"></div><div class="chatlog__markdown-quote-content">$1</div></div>`),u=u.replace(/\*\*([^*]+)\*\*/g,`<strong>$1</strong>`),u=u.replace(/__([^_]+)__/g,`<u>$1</u>`),u=u.replace(/\*([^*]+)\*/g,`<em>$1</em>`),u=u.replace(/(^|\s)_([^_]+)_(\s|$)/g,`$1<em>$2</em>$3`),u=u.replace(/~~([^~]+)~~/g,`<s>$1</s>`),u=u.replace(/\n/g,`<br>`);for(var f=s.length-1;f>=0;f--)u=u.replaceAll(`\u0000TOK_${f}\u0000`,s[f]);return u}function u(e,t=0){if(e?.id&&e?.avatar){var n=e.avatar.startsWith(`a_`)?`gif`:`webp`;return`https://cdn.discordapp.com/avatars/${e.id}/${e.avatar}.${n}?size=128`}return`https://cdn.discordapp.com/embed/avatars/${t%6}.png`}function d(e){return!e||e<=0?``:e<1024?`${e} B`:e<1048576?`${(e/1024).toFixed(1)} KB`:`${(e/1048576).toFixed(1)} MB`}function f(e){if(typeof e.content_type==`string`&&e.content_type.trim())return e.content_type.trim().toLowerCase();if(typeof e.original_content_type==`string`&&e.original_content_type.trim())return e.original_content_type.trim().toLowerCase();var t=(e.filename||``).toLowerCase();return/\.(mp4|webm|mov|m4v|mkv|avi|flv|wmv)$/i.test(t)?`video/mp4`:/\.(png|jpe?g|gif|webp|bmp|svg|tiff?)$/i.test(t)?`image/png`:/\.(mp3|wav|ogg|m4a|aac|opus)$/i.test(t)?`audio/mpeg`:``}function p(e){var t=f(e);if(t.startsWith(`video/`))return!0;var n=(e.filename||``).toLowerCase();return!!(/\.(mp4|webm|mov|m4v|mkv|avi|flv|wmv)$/i.test(n)||(e.width!=null&&e.width>0||e.height!=null&&e.height>0)&&!t.startsWith(`image/`)&&!t.startsWith(`audio/`))}function m(e){if(f(e).startsWith(`image/`))return!0;var t=(e.filename||``).toLowerCase();return!!/\.(png|jpe?g|gif|webp|bmp|svg|tiff?)$/i.test(t)}function h(e,t){if(p(e)||m(e))return!1;var n=f(e);return e.width!=null&&e.width>0||e.height!=null&&e.height>0?!1:!!(t&&t&8192||(e.flags??0)&8192||e.waveform||e.duration_secs!==void 0&&(n.startsWith(`audio/`)||!n||e.filename.endsWith(`.ogg`)||e.filename.endsWith(`.mp3`)||e.filename.endsWith(`.wav`)))}function g(e,t){if(h(e,t)||p(e)||m(e))return!1;if(f(e).startsWith(`audio/`))return!0;var n=(e.filename||``).toLowerCase();return/\.(mp3|wav|ogg|m4a|aac|opus)$/i.test(n)}function _(e){var t=n(e.filename),r=n(e.url||e.proxy_url||``),i=e.filename.startsWith(`SPOILER_`),a=i?` chatlog__attachment--hidden`:``,o=i?`<div class="chatlog__attachment-spoiler-caption">SPOILER</div>`:``;return p(e)?`<div class="chatlog__attachment-mosaic-item chatlog__attachment${a}" ${i?`onclick="showSpoiler(event, this)"`:``}>${o}<video class="chatlog__attachment-media" controls preload="metadata" src="${r}"></video></div>`:`<div class="chatlog__attachment-mosaic-item chatlog__attachment${a}" ${i?`onclick="showSpoiler(event, this)"`:``}>${o}<img class="chatlog__attachment-media" src="${r}" alt="${t}" loading="lazy" onclick="if (!this.closest('.chatlog__attachment--hidden')) openLightbox(this.src)" /></div>`}function v(e,t){var r=n(e.filename),i=n(e.url||e.proxy_url||``),a=d(e.size);if(h(e,t)){var o=e.duration_secs?Math.round(e.duration_secs):0;return`<div class="chatlog__attachment chatlog__attachment--voice"><div class="chatlog__voice-badge"><svg class="chatlog__voice-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"/><path fill="currentColor" d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/></svg><span>Voice Message${o>0?` (${o}s)`:``}</span></div><audio class="chatlog__attachment-audio" controls preload="metadata" src="${i}"></audio></div>`}if(m(e)){var s=e.filename.startsWith(`SPOILER_`);return`<div class="chatlog__attachment${s?` chatlog__attachment--hidden`:``}" ${s?`onclick="showSpoiler(event, this)"`:``}>${s?`<div class="chatlog__attachment-spoiler-caption">SPOILER</div>`:``}<img class="chatlog__attachment-media" src="${i}" alt="${r}" loading="lazy" onclick="if (!this.closest('.chatlog__attachment--hidden')) openLightbox(this.src)" /><div class="chatlog__attachment-info">${r} ${a?`(${a})`:``}</div></div>`}return p(e)?`<div class="chatlog__attachment"><video class="chatlog__attachment-media" controls preload="metadata" src="${i}"></video><div class="chatlog__attachment-info">${r} ${a?`(${a})`:``}</div></div>`:g(e,t)?`<div class="chatlog__attachment"><audio class="chatlog__attachment-audio" controls preload="metadata" src="${i}"></audio><div class="chatlog__attachment-info">${r} ${a?`(${a})`:``}</div></div>`:`<div class="chatlog__attachment-generic"><svg class="chatlog__attachment-generic-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg><div class="chatlog__attachment-generic-details"><a class="chatlog__attachment-generic-name" href="${i}" target="_blank" rel="noopener noreferrer">${r}</a>${a?`<span class="chatlog__attachment-generic-size">${a}</span>`:``}</div></div>`}function y(e,t){if(!e||e.length===0)return``;var n=[],r=[];for(var i of e)m(i)||p(i)?n.push(i):r.push(i);var a=``,o=``;n.length>=2?a=`<div class="chatlog__attachment-mosaic chatlog__attachment-mosaic--${Math.min(n.length,5)}">${n.map(_).join(``)}</div>`:n.length===1&&(o=v(n[0],t));var s=r.map(function(e){return v(e,t)}).join(``);return`<div class="chatlog__attachments">${a}${o}${s}</div>`}function b(e,t,r,i,a){var o=e.color?`#${e.color.toString(16).padStart(6,`0`)}`:`#202225`,s=e.author?.name?`<div class="chatlog__embed-author-container">${e.author.icon_url?`<img class="chatlog__embed-author-icon" src="${n(e.author.icon_url)}" alt="" loading="lazy" />`:``}<span class="chatlog__embed-author">${n(e.author.name)}</span></div>`:``,c=e.title?e.url?`<div class="chatlog__embed-title"><a href="${n(e.url)}" target="_blank" rel="noopener noreferrer">${n(e.title)}</a></div>`:`<div class="chatlog__embed-title">${n(e.title)}</div>`:``,u=e.description?`<div class="chatlog__embed-description">${l(e.description,t,r,i,a)}</div>`:``,d=``;e.fields&&e.fields.length>0&&(d=`<div class="chatlog__embed-fields">${e.fields.map(function(e){return`<div class="chatlog__embed-field ${e.inline?`chatlog__embed-field--inline`:``}"><div class="chatlog__embed-field-name">${n(e.name??e.rawName??``)}</div><div class="chatlog__embed-field-value">${l(e.value??e.rawValue??``,t,r,i,a)}</div></div>`}).join(``)}</div>`);var f=e.thumbnail?.url?`<img class="chatlog__embed-thumbnail" src="${n(e.thumbnail.url)}" alt="Thumbnail" loading="lazy" />`:``,p=e.image?.url?`<div class="chatlog__embed-images chatlog__embed-images--single"><img class="chatlog__embed-image" src="${n(e.image.url)}" alt="Image" loading="lazy" onclick="openLightbox('${n(e.image.url)}')" /></div>`:``,m=``;if(e.footer?.text||e.timestamp){var h=e.footer?.icon_url?`<img class="chatlog__embed-footer-icon" src="${n(e.footer.icon_url)}" alt="" loading="lazy" />`:``,g=e.footer?.text?n(e.footer.text):``,_=e.timestamp?new Date(e.timestamp).toLocaleString():``;m=`<div class="chatlog__embed-footer">${h}<span class="chatlog__embed-footer-text">${g}${g&&_?` • `:``}${_}</span></div>`}return`<div class="chatlog__embed"><div class="chatlog__embed-color-pill" style="background-color: ${o};"></div><div class="chatlog__embed-content-container"><div class="chatlog__embed-content"><div class="chatlog__embed-text">${s}${c}${u}${d}${p}${m}</div>${f}</div></div></div>`}function x(e){if(!e)return``;if(e.id){var t=e.animated?`gif`:`webp`,r=`https://cdn.discordapp.com/emojis/${e.id}.${t}?size=48&quality=lossless`;return`<img class="chatlog__component-emoji" alt="${n(e.name||``)}" src="${r}" loading="lazy" />`}return e.name?`<span class="chatlog__component-emoji-text">${n(e.name)}</span>`:``}function S(e){var t={1:`primary`,2:`secondary`,3:`success`,4:`danger`,5:`link`,6:`premium`}[Number(e.style)||2]||`secondary`,r=e.disabled?` chatlog__component-button--disabled`:``,i=x(e.emoji),a=e.label?`<span class="chatlog__component-button-label">${n(e.label)}</span>`:``;return e.url?`<a href="${n(e.url)}" target="_blank" rel="noopener noreferrer" class="chatlog__component-button chatlog__component-button--link${r}">${i}${a}<svg class="chatlog__component-button-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M10 5V3H5.00001C3.89544 3 3.00001 3.89543 3.00001 5V19C3.00001 20.1046 3.89544 21 5.00001 21H19C20.1046 21 21 20.1046 21 19V14H19V19H5.00001V5H10ZM14 3V5H17.5858L9.2929 13.2929L10.7071 14.7071L19 6.41421V10H21V3H14Z"/></svg></a>`:`<button type="button" class="chatlog__component-button chatlog__component-button--${t}${r}" ${e.disabled?`disabled`:``}>${i}${a}</button>`}function C(e){var t=e.placeholder||`Make a selection...`,r=e.disabled?` chatlog__component-select--disabled`:``,i=``;return e.options&&e.options.length>0&&(i=`<div class="chatlog__component-select-menu">${e.options.map(function(e){if(!e)return``;var t=x(e.emoji),r=e.description?`<span class="chatlog__component-select-option-desc">${n(e.description)}</span>`:``;return`<div class="chatlog__component-select-option${e.default?` selected`:``}">${t}<div class="chatlog__component-select-option-text"><span class="chatlog__component-select-option-label">${n(e.label||e.value||`Option`)}</span>${r}</div></div>`}).filter(Boolean).join(``)}</div>`),`<div class="chatlog__component-select${r}"><div class="chatlog__component-select-control"><span class="chatlog__component-select-placeholder">${n(t)}</span><svg class="chatlog__component-select-arrow" viewBox="0 0 24 24"><path fill="currentColor" d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"/></svg></div>${i}</div>`}function w(e,t,n,r,i){return e.content?`<div class="chatlog__component-text-display">${l(e.content,t,n,r,i)}</div>`:``}function T(e,t){var i=r(e.media?.url||(typeof e.media==`string`?e.media:``)||e.url||``,t);if(!i)return``;var a=n(e.description||`Thumbnail`),o=!!e.spoiler;return`<div class="chatlog__component-thumbnail${o?` chatlog__attachment--hidden`:``}" ${o?`onclick="showSpoiler(event, this)"`:``}>${o?`<div class="chatlog__attachment-spoiler-caption">SPOILER</div>`:``}<img class="chatlog__component-thumbnail-img" src="${n(i)}" alt="${a}" loading="lazy" onclick="openLightbox('${n(i)}')" /></div>`}function E(e,t){if(!e.items||e.items.length===0)return``;var i=Math.min(e.items.length,4),a=e.items.map(function(e){if(!e)return``;var i=r(e.media?.url||(typeof e.media==`string`?e.media:``)||e.url||``,t);if(!i)return``;var a=!!e.spoiler,o=a?` chatlog__attachment--hidden`:``,s=a?`<div class="chatlog__attachment-spoiler-caption">SPOILER</div>`:``,c=n(e.description||`Media item`);return`<div class="chatlog__component-media-item${o}" ${a?`onclick="showSpoiler(event, this)"`:``}>${s}<img class="chatlog__component-media-img" src="${n(i)}" alt="${c}" loading="lazy" onclick="openLightbox('${n(i)}')" /></div>`}).filter(Boolean).join(``);return a?`<div class="chatlog__component-media-gallery chatlog__component-media-gallery--${i}">${a}</div>`:``}function D(e,t){var r=e.file?.url||e.url||``,i=e.filename||e.file?.filename||``,a=e.size||e.file?.size;if(r.startsWith(`attachment://`)){var o=r.slice(13),s=t?.find(function(e){return e.filename===o});s&&(r=s.proxy_url||s.url,i||(i=s.filename),a||(a=s.size))}var c=n(r||`#`),l=n(i||`File Attachment`),u=d(a);return`<div class="chatlog__attachment-generic chatlog__component-file"><svg class="chatlog__attachment-generic-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg><div class="chatlog__attachment-generic-details"><a class="chatlog__attachment-generic-name" href="${c}" target="_blank" rel="noopener noreferrer">${l}</a>${u?`<span class="chatlog__attachment-generic-size">${u}</span>`:``}</div></div>`}function O(e){var t=!!e.divider,n=Number(e.spacing)||1;return`<div class="chatlog__component-separator${t?` chatlog__component-separator--divider`:``} chatlog__component-separator--spacing-${n}"></div>`}function k(e,t,n,r,i,a,o){var s=(e.components||[]).map(function(e){return M(e,t,n,r+1,i,a,o)}).join(``),c=e.accessory?M(e.accessory,t,n,r+1,i,a,o):``;return`<div class="chatlog__component-section"><div class="chatlog__component-section-content">${s}</div>${c?`<div class="chatlog__component-section-accessory">${c}</div>`:``}</div>`}function A(e,t,n,r,i,a,o){var s=e.accent_color?`#${e.accent_color.toString(16).padStart(6,`0`)}`:``,c=s?`border-left-color: ${s};`:``,l=!!e.spoiler,u=l?` chatlog__component-container--spoiler chatlog__markdown-spoiler--hidden`:``,d=(e.components||[]).map(function(e){return M(e,t,n,r+1,i,a,o)}).join(``);return`<div class="chatlog__component-container${u}" style="${c}" ${l?`onclick="showSpoiler(event, this)"`:``}><div class="chatlog__component-container-inner">${d}</div></div>`}function j(e,t,n,r,i,a,o){return`<div class="chatlog__component-action-row">${(e.components||[]).map(function(e){return M(e,t,n,r+1,i,a,o)}).join(``)}</div>`}function M(e,t,n,r=0,i,a,o){if(!e||r>10)return``;try{var s=Number(e.type),c=String(e.type).toLowerCase();return s===1||c===`action_row`?j(e,t,n,r,i,a,o):s===2||c===`button`?S(e):s===3||s===5||s===6||s===7||s===8||c.includes(`select`)?C(e):s===9||c===`section`?k(e,t,n,r,i,a,o):s===10||c===`text_display`?w(e,t,n,a,o):s===11||c===`thumbnail`?T(e,i):s===12||c===`media_gallery`?E(e,i):s===13||c===`file`?D(e,i):s===14||c===`separator`?O(e):s===17||c===`container`?A(e,t,n,r,i,a,o):``}catch{return``}}function ee(e,t,n,r,i,a){if(!e||e.length===0)return``;var o=e.map(function(e){return M(e,t,n,0,a,r,i)}).filter(Boolean).join(``);return o?`<div class="chatlog__components">${o}</div>`:``}function te(e){if(!e?.question)return``;try{var t=n(e.question.text||`Poll`),r=e.answers||[],i=e.results?.answer_counts||[],a=e.results?.total_votes??i.reduce(function(e,t){return e+(t.count||0)},0),o=r.map(function(e){var t=i.find(function(t){return t.id===e.answer_id})?.count??0,r=a>0?Math.round(t/a*100):0,o=``;if(e.poll_media?.emoji){var s=e.poll_media.emoji;if(s.id){var c=s.animated?`gif`:`webp`;o=`<img class="chatlog__emoji chatlog__emoji--small" alt="${n(s.name)}" src="https://cdn.discordapp.com/emojis/${s.id}.${c}?size=48&quality=lossless" loading="lazy" />`}else s.name&&(o=`<span class="chatlog__emoji">${n(s.name)}</span>`)}var l=n(e.poll_media?.text||``);return`<div class="chatlog__poll-answer"><div class="chatlog__poll-answer-fill" style="width: ${r}%;"></div><div class="chatlog__poll-answer-content"><span class="chatlog__poll-answer-text">${o}<span>${l}</span></span><span class="chatlog__poll-answer-votes">${t} (${r}%)</span></div></div>`}).join(``),s=e.results?.is_finalized?`<span class="chatlog__poll-status">Final Results</span>`:``;return`<div class="chatlog__poll"><div class="chatlog__poll-question">${t}</div><div class="chatlog__poll-answers">${o}</div><div class="chatlog__poll-footer"><span class="chatlog__poll-total">${`${a} vote${a===1?``:`s`}`}</span>${s}</div></div>`}catch{return``}}function N(e){var t=Number(e.type??0);if(t===0||t===19||t===20||t===23||e.messageSnapshots&&e.messageSnapshots.length>0||e.message_snapshots&&e.message_snapshots.length>0)return null;if(t===6)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M16 12V4H17V2H7V4H8V12L6 14V16H11V22H13V16H18V14L16 12Z"/></svg>`,text:`pinned a message to this channel.`};if(t===7||t===1){var r=`joined the server.`;if(t===1){var i=e.mentions?.[0],a=i?i.globalName||i.global_name||i.username:``;r=a?`added ${n(a)} to the group.`:`added a recipient to the group.`}return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M10 5.414 8.586 4 0.586 12l8 8 1.414-1.414L3.414 13H24v-2H3.414l6.586-6.586Z"/></svg>`,text:r}}if(t===2){var o=e.mentions?.[0],c=o?o.globalName||o.global_name||o.username:``;return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="m14 5.414 1.414-1.414 8 8-8 8-1.414-1.414L20.586 13H0v-2h20.586L14 5.414Z"/></svg>`,text:c?`removed ${n(c)} from the group.`:`removed a recipient from the group.`}}if(t>=8&&t<=11)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2L2 9.19V14.81L12 22L22 14.81V9.19L12 2ZM12 4.31L19.46 9.69L12 15.07L4.54 9.69L12 4.31Z"/></svg>`,text:t===8?`boosted the server!`:`boosted the server to Tier ${t-7}!`};if(t===18)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M4 4h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6l-4 4V6a2 2 0 0 1 2-2Z"/></svg>`,text:e.content?`started a thread: ${n(e.content)}`:`started a thread.`};if(t===21)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M4 4h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6l-4 4V6a2 2 0 0 1 2-2Z"/></svg>`,text:`started a thread starter message.`};if(t===4)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z"/></svg>`,text:e.content?`changed the channel name: ${n(e.content)}`:`changed the channel name.`};if(t===5)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>`,text:`changed the channel icon.`};if(t===3){var l=e.call?.duration?Math.max(1,Math.round(e.call.duration/60)):0;return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56-.35-.12-.74-.03-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 2 3 2.24 3 2.99 3 13.28 10.73 21 21.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z"/></svg>`,text:l>0?`started a call that lasted ${l} min.`:`started a call.`}}if(t===12)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z"/></svg>`,text:`added a channel follow to this channel.`};if(t===22)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>`,text:`reminded the server about guild invites.`};if(t===24)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M12 1 3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>`,text:`AutoMod caught a message.`};if(t===25)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="m12 17.27 6.18 3.73-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>`,text:`subscribed to the server.`};if(t===27)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M12 3a9 9 0 0 0-9 9v7c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2v-7a9 9 0 0 0-9-9zm0 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm7 12H5v-2.14c0-1.89 3.56-2.86 7-2.86s7 .97 7 2.86V19z"/></svg>`,text:`started a stage.`};if(t===28)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M12 3a9 9 0 0 0-9 9v7c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2v-7a9 9 0 0 0-9-9zm0 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm7 12H5v-2.14c0-1.89 3.56-2.86 7-2.86s7 .97 7 2.86V19z"/></svg>`,text:`ended a stage.`};if(t===29)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M12 3a9 9 0 0 0-9 9v7c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2v-7a9 9 0 0 0-9-9zm0 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm7 12H5v-2.14c0-1.89 3.56-2.86 7-2.86s7 .97 7 2.86V19z"/></svg>`,text:`became a speaker in the stage.`};if(t===31)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M12 3a9 9 0 0 0-9 9v7c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2v-7a9 9 0 0 0-9-9zm0 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm7 12H5v-2.14c0-1.89 3.56-2.86 7-2.86s7 .97 7 2.86V19z"/></svg>`,text:e.content?`changed the stage topic: ${n(e.content)}`:`changed the stage topic.`};if(t===32)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>`,text:`added an integration to this channel.`};if(t===36||t===44)return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M19 6h-2c0-2.76-2.24-5-5-5S7 3.24 7 6H5c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-7-3c1.66 0 3 1.34 3 3H9c0-1.66 1.34-3 3-3zm7 17H5V8h14v12z"/></svg>`,text:`purchased an item from the server shop.`};if(t===46){var u=s(e),d=`A poll has ended.`;if(u){var f=``;if(u.emojiId){var p=u.emojiAnimated?`gif`:`webp`;f=`<img class="chatlog__emoji chatlog__emoji--small" alt="${n(u.emojiName||``)}" src="https://cdn.discordapp.com/emojis/${u.emojiId}.${p}?size=48&quality=lossless" loading="lazy" /> `}else u.emojiName&&(f=`<span class="chatlog__emoji">${n(u.emojiName)}</span> `);var m=u.totalVotes?`(${u.victorVotes}/${u.totalVotes} votes)`:`(${u.victorVotes} votes)`;d=`A poll closed with ${f}<strong>${n(u.victorText)}</strong> winning: "${n(u.question)}" ${m}`}return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M4 19h4v-7H4v7zm6 0h4v-11h-4v11zm6 0h4V3h-4v16z"/></svg>`,text:d}}return{icon:`<svg class="chatlog__system-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>`,text:`system action performed.`}}function ne(e){var t=n(e.name||`Sticker`),r=e.format_type??e.formatType??1;if(r===3)return`<div class="chatlog__sticker" title="${t}"><lottie-player src="https://cdn.discordapp.com/stickers/${e.id}.json" autoplay loop mode="normal"></lottie-player><noscript><img class="chatlog__sticker--media" src="https://cdn.discordapp.com/stickers/${e.id}.png?size=160" alt="${t}" loading="lazy" /></noscript></div>`;var i=r===4?`gif`:`png`;return`<div class="chatlog__sticker" title="${t}"><img class="chatlog__sticker--media" src="https://cdn.discordapp.com/stickers/${e.id}.${i}?size=160" alt="${t}" loading="lazy" /></div>`}function re(e,t,r,i,a,o=0){if(!e||e.length===0||o>5)return``;try{var s=e.map(function(e){var s=e?.message??e;if(!s)return``;var c=``,d=!!(s.author&&(s.author.username&&s.author.username!==`Unknown`&&s.author.id!==`0`||s.author.globalName||s.nick)),f=s.timestamp?new Date(s.timestamp).getTime():0,p=f?new Date(f).toLocaleString():``;if(d&&s.author){var m=s.author,h=n(s.nick||m.globalName||m.username||`User`),g=n(m.username||``),_=(m.globalName||s.nick)&&m.globalName!==m.username&&s.nick!==m.username,v=s.colorString?`color: ${s.colorString};`:``,x=u(m,0),S=m.bot?`<span class="chatlog__author-tag">BOT</span>`:``,C=m.system?`<span class="chatlog__author-tag system">SYSTEM</span>`:``;c=`<div class="chatlog__forward-author-header"><img class="chatlog__forward-avatar" src="${x}" alt="${h}" loading="lazy" onerror="this.src='https://cdn.discordapp.com/embed/avatars/0.png'"/><span class="chatlog__forward-author-name" style="${v}">${h}</span>${_?`<span class="chatlog__forward-author-handle">@${g}</span>`:``}${S}${C}${p?`<span class="chatlog__forward-timestamp" title="${p}">${p}</span>`:``}</div>`}else p&&(c=`<div class="chatlog__forward-author-header"><span class="chatlog__forward-timestamp" title="${p}">${p}</span></div>`);var w=s.editedTimestamp??s.edited_timestamp,T=w?`<span class="chatlog__edited-timestamp" title="${new Date(w).toLocaleString()}">(edited)</span>`:``,E=s.content?l(s.content,t,r,i,a):``,D=``;s.attachments&&s.attachments.length>0&&(D=y(s.attachments,s.flags));var O=``;!(s.flags&&s.flags&4)&&s.embeds&&s.embeds.length>0&&(O=`<div class="chatlog__embeds">${s.embeds.map(function(e){return b(e,t,r,i,a)}).join(``)}</div>`);var k=``;s.components&&s.components.length>0&&(k=ee(s.components,t,r,i,a,s.attachments));var A=te(s.poll),j=``,M=s.stickerItems||s.stickers||s.sticker_items;Array.isArray(M)&&M.length>0&&(j=`<div class="chatlog__stickers">${M.map(function(e){return ne(e)}).join(``)}</div>`);var N=s.messageSnapshots||s.message_snapshots,ie=``;return Array.isArray(N)&&N.length>0&&(ie=re(N,t,r,i,a,o+1)),`<div class="chatlog__forward-card">${c}${E?`<div class="chatlog__forward-content chatlog__content">${E}${T}</div>`:``}${D}${O}${k}${A}${j}${ie}</div>`}).filter(Boolean).join(``);return s?`<div class="chatlog__forward-container"><div class="chatlog__forward-header"><svg class="chatlog__forward-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M12.2929 4.29289C12.6834 3.90237 13.3166 3.90237 13.7071 4.29289L20.7071 11.2929C21.0976 11.6834 21.0976 12.3166 20.7071 12.7071L13.7071 19.7071C13.3166 20.0976 12.6834 20.0976 12.2929 19.7071C11.9024 19.3166 11.9024 18.6834 12.2929 18.2929L17.5858 13H5C3.34315 13 2 11.6569 2 10C2 8.34315 3.34315 7 5 7H7C7.55228 7 8 7.44772 8 8C8 8.55228 7.55228 9 7 9H5C4.44772 9 4 9.44772 4 10C4 10.5523 4.44772 11 5 11H17.5858L12.2929 5.70711C11.9024 5.31658 11.9024 4.68342 12.2929 4.29289Z"/></svg><span class="chatlog__forward-label">Forwarded</span></div>${s}</div>`:``}catch{return``}}function ie(e){if(!e.reactions||e.reactions.length===0)return[];if(!e.poll)return e.reactions;var t=/* @__PURE__ */ new Set,n=/* @__PURE__ */ new Set;for(var r of e.poll.answers||[])r.poll_media?.emoji?.name&&t.add(r.poll_media.emoji.name),r.poll_media?.emoji?.id&&n.add(r.poll_media.emoji.id);return e.reactions.filter(function(e){return!(e.is_vote||e.emoji?.id&&n.has(e.emoji.id)||e.emoji?.name&&t.has(e.emoji.name)||t.size===0&&n.size===0)})}function P(e,t,r){var i=n(e.name),a=e.guildName?n(e.guildName):`Direct Message`,o=e.topic?n(e.topic):``,s=(/* @__PURE__ */ new Date()).toLocaleString(),c=/* @__PURE__ */ new Map,d=/* @__PURE__ */ new Map,f=/* @__PURE__ */ new Map,p=/* @__PURE__ */ new Map,m=e.id?valenced.discord.flux.Stores.ChannelStore?.getChannel?.(e.id)?.guild_id:void 0;e.id&&d.set(e.id,e.name);for(var h of t){h.id&&p.set(h.id,h),h.author?.id&&c.set(h.author.id,h.nick||h.author.globalName||h.author.username||`User`);var g=h.messageSnapshots||h.message_snapshots;if(Array.isArray(g))for(var _ of g){var v=_?.message?.author;v?.id&&c.set(v.id,v.globalName||v.username||`User`)}}for(var x=``,S=[],C=``,w=0,T=function(){var e=function(e){var i=S[e],a=e===0,o=i.author??{id:`0`,username:`Unknown`},s=n(i.nick||o.globalName||o.username||`Unknown`),h=n(o.username||``),g=(o.globalName||i.nick)&&o.globalName!==o.username&&i.nick!==o.username,_=i.colorString?`color: ${i.colorString};`:``,v=i.timestamp?new Date(i.timestamp).getTime():0,x=v?new Date(v).toLocaleString():``,C=v?new Date(v).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`}):``,w=N(i);if(w)return t+=`<div id="chatlog__message-container-${i.id}" class="chatlog__message-container chatlog__message-container--system" data-message-id="${i.id}"><div class="chatlog__message chatlog__message--system"><div class="chatlog__message-aside">${w.icon}</div><div class="chatlog__message-primary"><span class="chatlog__system-content"><span class="chatlog__author" style="${_}">${s}</span> <span class="chatlog__system-text">${w.text}</span></span>${r.includeTimestamps&&x?`<span class="chatlog__timestamp" title="${x}">${C||x}</span>`:``}</div></div></div>`,`continue`;var T=i.channel_id?valenced.discord.flux.Stores.ChannelStore?.getChannel?.(i.channel_id)?.guild_id??m:m,E=l(i.content??``,c,d,f,T),D=i.editedTimestamp??i.edited_timestamp,O=D?new Date(D).getTime():0,k=O?new Date(O).toLocaleString():``,A=O||typeof i.isEdited==`function`&&i.isEdited()?`<span class="chatlog__edited-timestamp" title="${k||`Edited`}">(edited)</span>`:``,j=te(i.poll),M=re(i.messageSnapshots||i.message_snapshots,c,d,f,T,0),P=``;r.includeAttachments&&i.attachments&&i.attachments.length>0&&(P=y(i.attachments,i.flags));var F=``,I=!!(i.flags&&i.flags&4);r.includeEmbeds&&!I&&i.embeds&&i.embeds.length>0&&(F=`<div class="chatlog__embeds">${i.embeds.map(function(e){return b(e,c,d,f,T)}).join(``)}</div>`);var L=``;(r.includeComponents??!0)&&i.components&&i.components.length>0&&(L=ee(i.components,c,d,f,T,i.attachments));var R=``,z=ie(i);z.length>0&&(R=`<div class="chatlog__reactions">${z.map(function(e){var t=e.emoji,r=e.count;if(t.id){var i=t.animated?`gif`:`webp`,a=`https://cdn.discordapp.com/emojis/${t.id}.${i}?size=48&quality=lossless`;return`<div class="chatlog__reaction" title="${n(t.name)}"><img class="chatlog__emoji chatlog__emoji--small" alt="${n(t.name)}" src="${a}" loading="lazy" /><span class="chatlog__reaction-count">${r}</span></div>`}return`<div class="chatlog__reaction" title="${n(t.name)}"><span class="chatlog__reaction-emoji">${n(t.name)}</span><span class="chatlog__reaction-count">${r}</span></div>`}).join(``)}</div>`);var B=``,V=i.stickerItems||i.stickers||i.sticker_items;Array.isArray(V)&&V.length>0&&(B=`<div class="chatlog__stickers">${V.map(function(e){return ne(e)}).join(``)}</div>`);var ae=!!(i.messageSnapshots&&i.messageSnapshots.length>0||i.message_snapshots&&i.message_snapshots.length>0||i.messageReference?.type===1),H=i.interactionMetadata||i.interaction,U=``;if(H){var W=H.user||H.author||{id:`0`,username:`User`},oe=n(W.globalName||W.username||`User`),G=n(H.name||`command`);U=`<div class="chatlog__interaction"><img class="chatlog__interaction-avatar" src="${u(W,0)}" alt="" loading="lazy" /><span class="chatlog__interaction-author">${oe}</span> <span class="chatlog__interaction-text">used</span> <span class="chatlog__interaction-command">/${G}</span></div>`}var K=``,q=i.referencedMessage?.id??i.messageReference?.message_id;if(q&&!ae){var J=i.referencedMessage??p.get(q);if(J){var se=n(J.nick||J.author?.globalName||J.author?.username||`User`),Y=J.colorString?`color: ${J.colorString};`:``;K=`<div class="chatlog__reply"><div class="chatlog__reply-symbol"></div><img class="chatlog__reply-avatar" src="${u(J.author,0)}" alt="" loading="lazy" /><span class="chatlog__reply-author" style="${Y}">${se}</span><a class="chatlog__reply-content chatlog__reply-link" onclick="scrollToMessage(event, '${q}')">${J.content?n(J.content.length>70?`${J.content.slice(0,70)}...`:J.content):J.attachments?.length?`Click to see attachment`:`Message`}</a></div>`}else K=`<div class="chatlog__reply"><div class="chatlog__reply-symbol"></div><a class="chatlog__reply-content chatlog__reply-link" onclick="scrollToMessage(event, '${q}')">Original message was deleted or not loaded.</a></div>`}if(a){var ce=u(o,0),le=o.bot?`<span class="chatlog__author-tag">BOT</span>`:``,ue=o.system?`<span class="chatlog__author-tag system">SYSTEM</span>`:``,X=i.pinned?`<span class="chatlog__pinned-badge" title="Pinned message"><svg class="chatlog__pinned-icon" viewBox="0 0 24 24"><path fill="currentColor" d="m16 12 2 2v2h-5v6l-1 1-1-1v-6H6v-2l2-2V5H7V3h10v2h-1v7Z"/></svg></span>`:``;t+=`<div id="chatlog__message-container-${i.id}" class="chatlog__message-container ${i.pinned?`chatlog__message-container--pinned`:``}" data-message-id="${i.id}"><div class="chatlog__message"><div class="chatlog__message-aside"><img class="chatlog__avatar" src="${ce}" alt="${s}" loading="lazy" onerror="this.src='https://cdn.discordapp.com/embed/avatars/0.png'"/></div><div class="chatlog__message-primary">${U}${K}<div class="chatlog__header"><span class="chatlog__author" style="${_}">${s}</span>${g?`<span class="chatlog__author-handle">@${h}</span>`:``}${le}${ue}${X}${r.includeTimestamps&&x?`<span class="chatlog__timestamp" title="${x}">${x}</span>`:``}</div><div class="chatlog__content">${E}${A}</div>${j}${M}${P}${F}${L}${B}${R}</div></div></div>`}else t+=`<div id="chatlog__message-container-${i.id}" class="chatlog__message-container ${i.pinned?`chatlog__message-container--pinned`:``}" data-message-id="${i.id}"><div class="chatlog__message chatlog__message--coalesced"><div class="chatlog__message-aside"><span class="chatlog__short-timestamp" title="${x}">${C}</span></div><div class="chatlog__message-primary">${U}${K}<div class="chatlog__content">${E}${A}</div>${j}${M}${P}${F}${L}${B}${R}</div></div></div>`};if(S.length!==0){for(var t=``,i=0;i<S.length;i++)e(i);x+=`<div class="chatlog__message-group">${t}</div>`,S=[]}},E=0;E<t.length;E++){var D=t[E],O=D.author?.id??`0`,k=D.timestamp?new Date(D.timestamp).getTime():0,A=!!(D.messageSnapshots&&D.messageSnapshots.length>0||D.message_snapshots&&D.message_snapshots.length>0||D.messageReference?.type===1),j=!(!D.referencedMessage&&!D.messageReference?.message_id||A),M=!!(D.interactionMetadata||D.interaction),P=N(D)!==null;!P&&!j&&!A&&!M&&S.length>0&&C===O&&k>0&&w>0&&k-w<3e5?(S.push(D),w=k):(T(),S.push(D),C=P?``:O,w=k,P&&T())}return T(),`<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>${a} - #${i}</title>
	<style>
		:root {
			--bg-primary: #313338;
			--bg-secondary: #2b2d31;
			--bg-tertiary: #1e1f22;
			--bg-hover: #2e3035;
			--text-normal: #dbdee1;
			--text-muted: #949ba4;
			--text-header: #f2f3f5;
			--brand-color: #5865f2;
			--brand-hover: #4752c4;
			--border-subtle: #3f4147;
			--mention-bg: rgba(88, 101, 242, 0.3);
			--mention-text: #dee0fc;
			--font-main: "gg sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
			--font-code: Consolas, "Andale Mono WT", "Andale Mono", "Lucida Console", "Courier New", Courier, monospace;
		}

		* {
			box-sizing: border-box;
			margin: 0;
			padding: 0;
		}

		html, body {
			background-color: var(--bg-primary);
			color: var(--text-normal);
			font-family: var(--font-main);
			font-size: 16px;
			line-height: 1.375;
			scroll-behavior: smooth;
		}

		a {
			color: #00a8fc;
			text-decoration: none;
		}

		a:hover {
			text-decoration: underline;
		}

				header {
			position: sticky;
			top: 0;
			z-index: 100;
			background-color: var(--bg-secondary);
			border-bottom: 1px solid var(--border-subtle);
			padding: 8px 16px;
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 12px;
			box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25);
			height: 48px;
		}

		.header-left {
			display: flex;
			align-items: center;
			gap: 8px;
			min-width: 0;
			flex: 1;
		}

		.channel-hash {
			color: var(--text-muted);
			font-size: 20px;
			font-weight: 600;
			flex-shrink: 0;
		}

		.channel-title-wrap {
			display: flex;
			align-items: baseline;
			gap: 8px;
			overflow: hidden;
			white-space: nowrap;
		}

		.channel-name {
			color: var(--text-header);
			font-size: 16px;
			font-weight: 700;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		.guild-name {
			color: var(--text-muted);
			font-size: 12px;
			font-weight: 500;
			flex-shrink: 0;
		}

		.topic-toggle-btn {
			background: transparent;
			border: 1px solid var(--border-subtle);
			color: var(--text-muted);
			font-size: 11px;
			font-weight: 600;
			padding: 2px 8px;
			border-radius: 4px;
			cursor: pointer;
			flex-shrink: 0;
			transition: background-color 0.15s, color 0.15s;
		}

		.topic-toggle-btn:hover {
			color: var(--text-normal);
			background-color: var(--bg-tertiary);
		}

		.header-right {
			display: flex;
			align-items: center;
			gap: 10px;
			flex-shrink: 0;
		}

		.search-box {
			display: flex;
			align-items: center;
			background-color: var(--bg-tertiary);
			border-radius: 4px;
			padding: 4px 8px;
			border: 1px solid transparent;
			transition: border-color 0.2s;
		}

		.search-box:focus-within {
			border-color: var(--brand-color);
		}

		.search-box input {
			background: transparent;
			border: none;
			outline: none;
			color: var(--text-normal);
			font-size: 13px;
			font-family: inherit;
			width: 130px;
		}

		.search-box input::placeholder {
			color: var(--text-muted);
		}

		.stats-badge {
			background-color: var(--bg-tertiary);
			color: var(--text-muted);
			font-size: 11px;
			padding: 4px 8px;
			border-radius: 4px;
			white-space: nowrap;
		}

				.topic-panel {
			position: sticky;
			top: 48px;
			z-index: 90;
			background-color: rgba(30, 31, 34, 0.95);
			backdrop-filter: blur(8px);
			border-bottom: 1px solid var(--border-subtle);
			padding: 10px 16px;
			font-size: 13px;
			color: var(--text-muted);
			transition: max-height 0.2s ease, opacity 0.2s ease;
			overflow: hidden;
		}

		.topic-panel.collapsed {
			display: none;
		}

				.preamble {
			display: grid;
			grid-template-columns: auto 1fr;
			max-width: 1200px;
			margin: 0 auto;
			padding: 24px 16px 16px 16px;
			gap: 16px;
		}

		.preamble__guild-icon-container {
			grid-column: 1;
		}

		.preamble__guild-icon {
			width: 72px;
			height: 72px;
			border-radius: 18px;
			object-fit: cover;
		}

		.preamble__guild-icon-placeholder {
			width: 72px;
			height: 72px;
			border-radius: 18px;
			background-color: var(--brand-color);
			color: #fff;
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 32px;
			font-weight: 700;
		}

		.preamble__entries-container {
			grid-column: 2;
			display: flex;
			flex-direction: column;
			justify-content: center;
			gap: 4px;
		}

		.preamble__entry {
			color: var(--text-header);
			font-size: 1.3rem;
			font-weight: 700;
		}

		.preamble__channel-title {
			font-size: 1.1rem;
			color: var(--text-normal);
		}

		.preamble__entry--small {
			font-size: 0.875rem;
			font-weight: 400;
			color: var(--text-muted);
		}

				.chatlog {
			padding: 8px 0 40px 0;
			width: 100%;
			max-width: 1200px;
			margin: 0 auto;
		}

		.chatlog__message-group {
			margin-bottom: 12px;
		}

		.chatlog__message-container {
			background-color: transparent;
			transition: background-color 0.8s ease;
		}

		.chatlog__message-container--highlighted {
			background-color: rgba(114, 137, 218, 0.25) !important;
		}

		.chatlog__message-container--pinned {
			background-color: rgba(249, 168, 37, 0.05);
		}

		.chatlog__pinned-badge {
			display: inline-flex;
			align-items: center;
			margin-left: 6px;
			color: #f9a825;
			vertical-align: middle;
		}

		.chatlog__pinned-icon {
			width: 14px;
			height: 14px;
		}

		.chatlog__message {
			display: grid;
			grid-template-columns: 72px 1fr;
			padding: 2px 16px;
			min-height: 28px;
			transition: background-color 0.1s;
		}

		.chatlog__message:hover {
			background-color: var(--bg-hover);
		}

		.chatlog__message-aside {
			grid-column: 1;
			width: 72px;
			text-align: center;
			padding-top: 2px;
			flex-shrink: 0;
		}

		.chatlog__avatar {
			width: 40px;
			height: 40px;
			border-radius: 50%;
			object-fit: cover;
		}

		.chatlog__short-timestamp {
			display: none;
			color: var(--text-muted);
			font-size: 0.6875rem;
			font-weight: 500;
			line-height: 22px;
			user-select: none;
		}

		.chatlog__message:hover .chatlog__short-timestamp {
			display: block;
		}

		.chatlog__message-primary {
			grid-column: 2;
			min-width: 0;
			padding-right: 12px;
		}

				.chatlog__reply {
			display: flex;
			align-items: center;
			margin-bottom: 4px;
			font-size: 0.8125rem;
			color: #b5b6b8;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		.chatlog__reply-symbol {
			width: 12px;
			height: 8px;
			margin-right: 6px;
			margin-left: 20px;
			border-left: 2px solid #4f545c;
			border-top: 2px solid #4f545c;
			border-top-left-radius: 6px;
			flex-shrink: 0;
		}

		.chatlog__reply-avatar {
			width: 16px;
			height: 16px;
			margin-right: 6px;
			border-radius: 50%;
			flex-shrink: 0;
		}

		.chatlog__reply-author {
			margin-right: 6px;
			font-weight: 600;
			color: #fff;
			flex-shrink: 0;
		}

		.chatlog__reply-link {
			color: #b5b6b8;
			cursor: pointer;
			overflow: hidden;
			text-overflow: ellipsis;
			text-decoration: none;
		}

		.chatlog__reply-link:hover {
			color: #fff;
			text-decoration: underline;
		}

				.chatlog__header {
			display: flex;
			align-items: baseline;
			gap: 6px;
			margin-bottom: 2px;
		}

		.chatlog__author {
			font-weight: 600;
			color: #ffffff;
			font-size: 1rem;
		}

		.chatlog__author-handle {
			font-size: 0.75rem;
			color: var(--text-muted);
		}

		.chatlog__author-tag {
			font-size: 0.625rem;
			font-weight: 700;
			background-color: var(--brand-color);
			color: #ffffff;
			padding: 1px 4px;
			border-radius: 3px;
			line-height: 1.2;
		}

		.chatlog__author-tag.system {
			background-color: #eb459e;
		}

		.chatlog__timestamp {
			color: var(--text-muted);
			font-size: 0.75rem;
			font-weight: 500;
			margin-left: 4px;
		}

				.chatlog__content {
			font-size: 0.95rem;
			color: var(--text-normal);
			word-wrap: break-word;
			line-height: 1.375;
		}

		.chatlog__content:empty {
			display: none;
		}

		.chatlog__content h1 { font-size: 1.4rem; font-weight: 700; margin: 8px 0 4px 0; color: var(--text-header); }
		.chatlog__content h2 { font-size: 1.2rem; font-weight: 700; margin: 6px 0 3px 0; color: var(--text-header); }
		.chatlog__content h3 { font-size: 1.05rem; font-weight: 600; margin: 4px 0 2px 0; color: var(--text-header); }
		.chatlog__markdown-subtext { font-size: 0.75rem; color: var(--text-muted); margin-top: 2px; }

		.chatlog__markdown-quote {
			display: flex;
			margin: 4px 0;
		}

		.chatlog__markdown-quote-border {
			margin-right: 8px;
			border-left: 4px solid #4f545c;
			border-radius: 2px;
		}

		.chatlog__markdown-quote-content {
			color: var(--text-normal);
		}

		.chatlog__markdown-pre {
			background-color: var(--bg-secondary);
			font-family: var(--font-code);
			font-size: 0.85rem;
		}

		.chatlog__markdown-pre--multiline {
			display: block;
			margin: 6px 0;
			padding: 10px 12px;
			border: 1px solid var(--border-subtle);
			border-radius: 4px;
			color: #b9bbbe;
			white-space: pre-wrap;
			overflow-x: auto;
		}

		.chatlog__markdown-pre--inline {
			display: inline-block;
			padding: 2px 4px;
			border-radius: 3px;
		}

		.chatlog__markdown-mention {
			border-radius: 3px;
			padding: 0 4px;
			background-color: var(--mention-bg);
			color: var(--mention-text);
			font-weight: 500;
		}

		.chatlog__markdown-mention--role {
			background-color: rgba(255, 255, 255, 0.08);
			font-weight: 600;
		}

		.chatlog__markdown-mention:hover {
			background-color: var(--brand-color);
			color: #ffffff;
		}

		.chatlog__markdown-timestamp {
			background-color: rgba(255, 255, 255, 0.08);
			padding: 1px 4px;
			border-radius: 3px;
			font-size: 0.85rem;
		}

		.chatlog__emoji {
			width: 1.375rem;
			height: 1.375rem;
			vertical-align: -0.35rem;
			object-fit: contain;
			margin: 0 1px;
		}

		.chatlog__emoji--small {
			width: 1rem;
			height: 1rem;
		}

		.chatlog__emoji--large {
			width: 2.75rem;
			height: 2.75rem;
		}

				.chatlog__markdown-spoiler {
			background-color: rgba(255, 255, 255, 0.1);
			padding: 0 3px;
			border-radius: 3px;
		}

		.chatlog__markdown-spoiler--hidden {
			cursor: pointer;
			background-color: #202225;
			color: transparent;
			user-select: none;
		}

		.chatlog__markdown-spoiler--hidden:hover {
			background-color: rgba(32, 34, 37, 0.8);
		}

				.chatlog__attachments {
			margin-top: 6px;
			display: flex;
			flex-direction: column;
			gap: 8px;
		}

		.chatlog__attachment-mosaic {
			display: grid;
			gap: 4px;
			border-radius: 8px;
			overflow: hidden;
			margin-top: 4px;
			max-width: 550px;
		}

		.chatlog__attachment-mosaic--2 {
			grid-template-columns: 1fr 1fr;
		}

		.chatlog__attachment-mosaic--3 {
			grid-template-columns: 1fr 1fr;
		}

		.chatlog__attachment-mosaic--3 .chatlog__attachment-mosaic-item:first-child {
			grid-row: span 2;
		}

		.chatlog__attachment-mosaic--4 {
			grid-template-columns: 1fr 1fr;
		}

		.chatlog__attachment-mosaic--5 {
			grid-template-columns: repeat(3, 1fr);
		}

		.chatlog__attachment-mosaic-item {
			position: relative;
			overflow: hidden;
			border-radius: 4px;
			max-height: 280px;
			display: flex;
			align-items: center;
			justify-content: center;
			background-color: var(--bg-secondary);
		}

		.chatlog__attachment-mosaic-item .chatlog__attachment-media {
			width: 100%;
			height: 100%;
			max-width: 100%;
			max-height: 280px;
			object-fit: cover;
		}

		.chatlog__attachment {
			position: relative;
			width: fit-content;
			border-radius: 4px;
			overflow: hidden;
		}

		.chatlog__attachment-media {
			max-width: 45vw;
			max-height: 450px;
			border-radius: 4px;
			display: block;
			object-fit: contain;
			cursor: pointer;
			transition: opacity 0.2s;
		}

		.chatlog__attachment-media:hover {
			opacity: 0.95;
		}

		.chatlog__attachment-audio {
			width: 100%;
			max-width: 400px;
		}

		.chatlog__attachment-info {
			font-size: 0.75rem;
			color: var(--text-muted);
			margin-top: 4px;
		}

		.chatlog__attachment--hidden {
			cursor: pointer;
		}

		.chatlog__attachment--hidden .chatlog__attachment-media {
			filter: blur(44px);
		}

		.chatlog__attachment-spoiler-caption {
			display: none;
			position: absolute;
			left: 50%;
			top: 50%;
			z-index: 10;
			padding: 6px 14px;
			border-radius: 20px;
			transform: translate(-50%, -50%);
			background-color: rgba(0, 0, 0, 0.85);
			color: #dcddde;
			font-size: 13px;
			font-weight: 700;
			letter-spacing: 0.5px;
		}

		.chatlog__attachment--hidden .chatlog__attachment-spoiler-caption {
			display: block;
		}

		.chatlog__attachment-generic {
			display: inline-flex;
			align-items: center;
			gap: 12px;
			background-color: var(--bg-secondary);
			border: 1px solid var(--border-subtle);
			border-radius: 6px;
			padding: 10px 14px;
			max-width: 420px;
		}

		.chatlog__attachment-generic-icon {
			color: var(--text-muted);
			width: 24px;
			height: 24px;
			flex-shrink: 0;
		}

		.chatlog__attachment-generic-details {
			display: flex;
			flex-direction: column;
			overflow: hidden;
		}

		.chatlog__attachment-generic-name {
			color: #00a8fc;
			font-size: 14px;
			font-weight: 600;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		.chatlog__attachment-generic-size {
			font-size: 11px;
			color: var(--text-muted);
		}

				.chatlog__embeds {
			margin-top: 6px;
			display: flex;
			flex-direction: column;
			gap: 8px;
		}

		.chatlog__embed {
			display: flex;
			margin-top: 4px;
			max-width: 520px;
		}

		.chatlog__embed-color-pill {
			flex-shrink: 0;
			width: 4px;
			border-top-left-radius: 4px;
			border-bottom-left-radius: 4px;
		}

		.chatlog__embed-content-container {
			display: flex;
			flex-direction: column;
			padding: 10px 14px;
			border: 1px solid var(--border-subtle);
			border-top-right-radius: 4px;
			border-bottom-right-radius: 4px;
			background-color: var(--bg-secondary);
			width: 100%;
		}

		.chatlog__embed-content {
			display: flex;
			width: 100%;
		}

		.chatlog__embed-text {
			flex: 1;
		}

		.chatlog__embed-author-container {
			display: flex;
			align-items: center;
			gap: 6px;
			margin-bottom: 4px;
		}

		.chatlog__embed-author-icon {
			width: 18px;
			height: 18px;
			border-radius: 50%;
		}

		.chatlog__embed-author {
			color: var(--text-header);
			font-size: 0.8125rem;
			font-weight: 600;
		}

		.chatlog__embed-title {
			color: var(--text-header);
			font-size: 0.9375rem;
			font-weight: 700;
			margin-bottom: 4px;
		}

		.chatlog__embed-description {
			font-size: 0.875rem;
			color: var(--text-normal);
			margin-bottom: 6px;
			word-wrap: break-word;
		}

		.chatlog__embed-fields {
			display: grid;
			grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
			gap: 8px;
			margin-top: 6px;
		}

		.chatlog__embed-field-name {
			font-size: 0.75rem;
			font-weight: 700;
			color: var(--text-header);
		}

		.chatlog__embed-field-value {
			font-size: 0.8125rem;
			color: var(--text-normal);
		}

		.chatlog__embed-thumbnail {
			max-width: 80px;
			max-height: 80px;
			margin-left: 12px;
			border-radius: 4px;
			object-fit: cover;
		}

		.chatlog__embed-image {
			max-width: 100%;
			max-height: 350px;
			border-radius: 4px;
			margin-top: 6px;
			cursor: pointer;
		}

		.chatlog__embed-footer {
			margin-top: 8px;
			display: flex;
			align-items: center;
			gap: 6px;
			color: var(--text-muted);
			font-size: 0.6875rem;
		}

		.chatlog__embed-footer-icon {
			width: 16px;
			height: 16px;
			border-radius: 50%;
		}

				.chatlog__reactions {
			display: flex;
			flex-wrap: wrap;
			gap: 4px;
			margin-top: 6px;
		}

		.chatlog__reaction {
			display: inline-flex;
			align-items: center;
			gap: 4px;
			padding: 2px 6px;
			border: 1px solid transparent;
			border-radius: 8px;
			background-color: var(--bg-secondary);
			cursor: default;
			transition: border-color 0.15s;
		}

		.chatlog__reaction:hover {
			border-color: rgba(255, 255, 255, 0.2);
		}

		.chatlog__reaction-count {
			color: var(--text-muted);
			font-size: 0.75rem;
			font-weight: 600;
		}

				.chatlog__stickers {
			margin-top: 6px;
		}

		.chatlog__sticker {
			width: 160px;
			height: 160px;
		}

		.chatlog__sticker lottie-player {
			width: 100%;
			height: 100%;
		}

		.chatlog__sticker--media {
			max-width: 100%;
			max-height: 100%;
			object-fit: contain;
		}

		.chatlog__components {
			margin-top: 6px;
			display: flex;
			flex-direction: column;
			gap: 6px;
			max-width: 540px;
		}

		.chatlog__component-container {
			background-color: var(--bg-secondary);
			border: 1px solid var(--border-subtle);
			border-radius: 8px;
			padding: 10px 12px;
			margin: 4px 0;
			border-left: 4px solid var(--border-subtle);
			transition: filter 0.2s;
		}

		.chatlog__component-container--spoiler {
			cursor: pointer;
		}

		.chatlog__component-container-inner {
			display: flex;
			flex-direction: column;
			gap: 6px;
		}

		.chatlog__component-section {
			display: flex;
			justify-content: space-between;
			align-items: flex-start;
			gap: 12px;
			margin: 2px 0;
		}

		.chatlog__component-section-content {
			flex: 1;
			display: flex;
			flex-direction: column;
			gap: 4px;
		}

		.chatlog__component-section-accessory {
			flex-shrink: 0;
			display: flex;
			align-items: center;
			justify-content: center;
		}

		.chatlog__component-text-display {
			color: var(--text-normal);
			font-size: 0.9375rem;
			line-height: 1.375;
			word-break: break-word;
		}

		.chatlog__component-thumbnail {
			position: relative;
			max-width: 80px;
			max-height: 80px;
			border-radius: 6px;
			overflow: hidden;
			flex-shrink: 0;
		}

		.chatlog__component-thumbnail-img {
			width: 80px;
			height: 80px;
			object-fit: cover;
			border-radius: 6px;
			cursor: pointer;
			display: block;
		}

		.chatlog__component-media-gallery {
			display: grid;
			gap: 4px;
			border-radius: 8px;
			overflow: hidden;
			margin: 4px 0;
			max-width: 520px;
		}

		.chatlog__component-media-gallery--1 {
			grid-template-columns: 1fr;
		}

		.chatlog__component-media-gallery--2 {
			grid-template-columns: 1fr 1fr;
		}

		.chatlog__component-media-gallery--3 {
			grid-template-columns: 1fr 1fr;
		}

		.chatlog__component-media-gallery--4 {
			grid-template-columns: 1fr 1fr;
		}

		.chatlog__component-media-item {
			position: relative;
			overflow: hidden;
			max-height: 240px;
		}

		.chatlog__component-media-img {
			width: 100%;
			height: 100%;
			object-fit: cover;
			cursor: pointer;
			display: block;
		}

		.chatlog__component-separator {
			width: 100%;
		}

		.chatlog__component-separator--divider {
			border-bottom: 1px solid var(--border-subtle);
		}

		.chatlog__component-separator--spacing-1 {
			margin: 6px 0;
		}

		.chatlog__component-separator--spacing-2 {
			margin: 12px 0;
		}

		.chatlog__component-separator--spacing-3 {
			margin: 18px 0;
		}

		.chatlog__component-action-row {
			display: flex;
			flex-wrap: wrap;
			gap: 8px;
			align-items: center;
			margin: 4px 0;
		}

		.chatlog__component-button {
			display: inline-flex;
			align-items: center;
			justify-content: center;
			gap: 6px;
			padding: 6px 14px;
			border-radius: 4px;
			font-size: 0.875rem;
			font-weight: 500;
			border: none;
			cursor: pointer;
			text-decoration: none;
			transition: background-color 0.15s, opacity 0.15s;
			max-width: 100%;
		}

		.chatlog__component-button--primary {
			background-color: #5865F2;
			color: #fff;
		}

		.chatlog__component-button--primary:hover {
			background-color: #4752c4;
		}

		.chatlog__component-button--secondary {
			background-color: #4e5058;
			color: #fff;
		}

		.chatlog__component-button--secondary:hover {
			background-color: #6d6f78;
		}

		.chatlog__component-button--success {
			background-color: #248046;
			color: #fff;
		}

		.chatlog__component-button--success:hover {
			background-color: #1a6334;
		}

		.chatlog__component-button--danger {
			background-color: #da373c;
			color: #fff;
		}

		.chatlog__component-button--danger:hover {
			background-color: #a12828;
		}

		.chatlog__component-button--link {
			background-color: #4e5058;
			color: #fff;
		}

		.chatlog__component-button--link:hover {
			background-color: #6d6f78;
		}

		.chatlog__component-button--premium {
			background: linear-gradient(90deg, #f47b67, #8045dd);
			color: #fff;
		}

		.chatlog__component-button--disabled {
			opacity: 0.5;
			cursor: not-allowed;
		}

		.chatlog__component-button-icon {
			width: 16px;
			height: 16px;
			fill: currentColor;
			margin-left: 2px;
			flex-shrink: 0;
		}

		.chatlog__component-emoji {
			width: 18px;
			height: 18px;
			object-fit: contain;
			vertical-align: middle;
		}

		.chatlog__component-select {
			background-color: var(--bg-secondary);
			border: 1px solid var(--border-subtle);
			border-radius: 4px;
			width: 100%;
			max-width: 440px;
			margin: 4px 0;
			overflow: hidden;
		}

		.chatlog__component-select-control {
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: 8px 12px;
			cursor: pointer;
			user-select: none;
		}

		.chatlog__component-select-placeholder {
			color: var(--text-muted);
			font-size: 0.875rem;
		}

		.chatlog__component-select-arrow {
			width: 18px;
			height: 18px;
			fill: var(--text-muted);
		}

		.chatlog__component-select-menu {
			border-top: 1px solid var(--border-subtle);
			max-height: 160px;
			overflow-y: auto;
			background-color: var(--bg-primary);
		}

		.chatlog__component-select-option {
			display: flex;
			align-items: center;
			gap: 8px;
			padding: 6px 12px;
			border-bottom: 1px solid rgba(255, 255, 255, 0.03);
			font-size: 0.8125rem;
			color: var(--text-normal);
		}

		.chatlog__component-select-option.selected {
			background-color: rgba(88, 101, 242, 0.15);
			color: #fff;
		}

		.chatlog__component-select-option-desc {
			font-size: 0.75rem;
			color: var(--text-muted);
			margin-left: 4px;
		}

		.chatlog__message-container--system {
			padding: 4px 0;
		}

		.chatlog__message--system {
			display: flex;
			align-items: center;
			gap: 12px;
			min-height: 28px;
		}

		.chatlog__system-icon {
			width: 18px;
			height: 18px;
			color: var(--text-muted);
			display: inline-flex;
			align-items: center;
			justify-content: center;
		}

		.chatlog__system-icon svg {
			width: 100%;
			height: 100%;
		}

		.chatlog__system-content {
			display: inline-flex;
			align-items: center;
			gap: 6px;
			font-size: 14px;
			color: var(--text-muted);
		}

		.chatlog__system-text {
			color: var(--text-muted);
		}

		.chatlog__poll {
			background-color: var(--bg-secondary);
			border: 1px solid var(--border-subtle);
			border-radius: 8px;
			padding: 16px;
			max-width: 520px;
			margin-top: 6px;
			display: flex;
			flex-direction: column;
			gap: 12px;
		}

		.chatlog__poll-question {
			font-size: 16px;
			font-weight: 700;
			color: var(--text-header);
		}

		.chatlog__poll-answers {
			display: flex;
			flex-direction: column;
			gap: 8px;
		}

		.chatlog__poll-answer {
			position: relative;
			background-color: var(--bg-primary);
			border: 1px solid var(--border-subtle);
			border-radius: 6px;
			overflow: hidden;
			min-height: 40px;
			display: flex;
			align-items: center;
		}

		.chatlog__poll-answer-fill {
			position: absolute;
			top: 0;
			bottom: 0;
			left: 0;
			background-color: rgba(88, 101, 242, 0.25);
			pointer-events: none;
		}

		.chatlog__poll-answer-content {
			position: relative;
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: 8px 12px;
			gap: 8px;
			z-index: 1;
		}

		.chatlog__poll-answer-text {
			font-size: 14px;
			font-weight: 500;
			color: var(--text-normal);
			display: flex;
			align-items: center;
			gap: 6px;
		}

		.chatlog__poll-answer-votes {
			font-size: 12px;
			font-weight: 600;
			color: var(--text-muted);
			white-space: nowrap;
		}

		.chatlog__poll-footer {
			display: flex;
			align-items: center;
			justify-content: space-between;
			font-size: 12px;
			color: var(--text-muted);
			padding-top: 4px;
			border-top: 1px solid var(--border-subtle);
		}

		.chatlog__poll-status {
			font-weight: 600;
			color: #949ba4;
		}

		.chatlog__forward-container {
			margin-top: 6px;
			margin-bottom: 4px;
			display: flex;
			flex-direction: column;
			gap: 6px;
			max-width: 560px;
		}

		.chatlog__forward-header {
			display: flex;
			align-items: center;
			gap: 6px;
			color: var(--text-muted);
			font-size: 12px;
			font-weight: 600;
			user-select: none;
		}

		.chatlog__forward-icon {
			width: 14px;
			height: 14px;
			flex-shrink: 0;
			color: var(--text-muted);
		}

		.chatlog__forward-label {
			font-size: 12px;
			font-weight: 600;
			color: var(--text-muted);
		}

		.chatlog__forward-card {
			background-color: var(--bg-secondary);
			border: 1px solid var(--border-subtle);
			border-left: 3px solid #5865f2;
			border-radius: 8px;
			padding: 12px 14px;
			display: flex;
			flex-direction: column;
			gap: 8px;
		}

		.chatlog__forward-author-header {
			display: flex;
			align-items: center;
			gap: 8px;
			flex-wrap: wrap;
		}

		.chatlog__forward-avatar {
			width: 20px;
			height: 20px;
			border-radius: 50%;
			object-fit: cover;
			flex-shrink: 0;
		}

		.chatlog__forward-author-name {
			font-size: 14px;
			font-weight: 600;
			color: var(--text-header);
		}

		.chatlog__forward-author-handle {
			font-size: 12px;
			color: var(--text-muted);
		}

		.chatlog__forward-timestamp {
			font-size: 11px;
			color: var(--text-muted);
			margin-left: 2px;
		}

		.chatlog__forward-content {
			font-size: 15px;
			color: var(--text-normal);
		}

		.chatlog__edited-timestamp {
			margin-left: 4px;
			font-size: 0.625rem;
			line-height: 1;
			color: var(--text-muted);
			cursor: default;
			user-select: none;
		}

		.chatlog__interaction {
			display: flex;
			align-items: center;
			gap: 6px;
			margin-bottom: 4px;
			font-size: 0.8125rem;
			color: var(--text-muted);
		}

		.chatlog__interaction-avatar {
			width: 14px;
			height: 14px;
			border-radius: 50%;
			object-fit: cover;
		}

		.chatlog__interaction-author {
			font-weight: 600;
			color: var(--text-normal);
		}

		.chatlog__interaction-text {
			color: var(--text-muted);
		}

		.chatlog__interaction-command {
			color: var(--brand-color);
			font-weight: 500;
		}

		.chatlog__attachment--voice {
			display: flex;
			flex-direction: column;
			gap: 6px;
			background-color: var(--bg-secondary);
			border: 1px solid var(--border-subtle);
			border-radius: 8px;
			padding: 8px 12px;
			max-width: 400px;
		}

		.chatlog__voice-badge {
			display: inline-flex;
			align-items: center;
			gap: 6px;
			font-size: 12px;
			font-weight: 600;
			color: var(--brand-color);
		}

		.chatlog__voice-icon {
			width: 14px;
			height: 14px;
		}

		.postamble {
			padding: 24px 16px;
			max-width: 1200px;
			margin: 0 auto;
			border-top: 1px solid var(--border-subtle);
			color: var(--text-muted);
			font-size: 0.8125rem;
			display: flex;
			flex-direction: column;
			gap: 4px;
		}

		.postamble__entry:first-child {
			color: var(--text-header);
			font-weight: 600;
		}

				.lightbox-modal {
			display: none;
			position: fixed;
			top: 0;
			left: 0;
			width: 100vw;
			height: 100vh;
			background-color: rgba(0, 0, 0, 0.88);
			backdrop-filter: blur(6px);
			z-index: 9999;
			align-items: center;
			justify-content: center;
			cursor: zoom-out;
			padding: 16px;
		}

		.lightbox-modal.active {
			display: flex;
		}

		.lightbox-box {
			display: flex;
			align-items: center;
			justify-content: center;
			max-width: 95vw;
			max-height: 95vh;
			cursor: default;
		}

		.lightbox-img {
			max-width: 90vw;
			max-height: 85vh;
			object-fit: contain;
			border-radius: 6px;
			box-shadow: 0 8px 32px rgba(0, 0, 0, 0.8);
		}

				.floating-actions {
			position: fixed;
			bottom: 24px;
			right: 24px;
			display: flex;
			flex-direction: column;
			gap: 10px;
			z-index: 999;
		}

		.floating-btn {
			width: 40px;
			height: 40px;
			border-radius: 50%;
			background-color: var(--brand-color);
			color: #fff;
			border: none;
			cursor: pointer;
			display: flex;
			align-items: center;
			justify-content: center;
			box-shadow: 0 4px 10px rgba(0, 0, 0, 0.4);
			transition: background-color 0.2s, transform 0.1s;
		}

		.floating-btn:hover {
			background-color: var(--brand-hover);
			transform: scale(1.05);
		}

		.floating-btn svg {
			fill: currentColor;
			width: 18px;
			height: 18px;
		}

		@media (max-width: 768px) {
			header {
				padding: 6px 12px;
			}
			.search-box input {
				width: 90px;
			}
			.chatlog__message {
				grid-template-columns: 52px 1fr;
				padding: 2px 8px;
			}
			.chatlog__message-aside {
				width: 52px;
			}
			.chatlog__avatar {
				width: 34px;
				height: 34px;
			}
			.chatlog__attachment-media {
				max-width: 75vw;
			}
		}
	</style>
	<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"><\/script>
</head>
<body>
	<header>
		<div class="header-left">
			<span class="channel-hash">#</span>
			<div class="channel-title-wrap">
				<span class="channel-name">${i}</span>
				<span class="guild-name">${a}</span>
			</div>
			${o?`<button class="topic-toggle-btn" onclick="toggleTopic()">Topic</button>`:``}
		</div>
		<div class="header-right">
			<div class="search-box">
				<input type="text" id="searchInput" placeholder="Search..." />
			</div>
			<div class="stats-badge" id="statsBadge" title="Exported ${s}">
				${t.length} msgs
			</div>
		</div>
	</header>

	${o?`<div id="topicPanel" class="topic-panel collapsed">${o}</div>`:``}

	<div class="preamble">
		<div class="preamble__guild-icon-container">
			${e.guildIconUrl?`<img class="preamble__guild-icon" src="${n(e.guildIconUrl)}" alt="Guild icon" loading="lazy" />`:`<div class="preamble__guild-icon-placeholder">#</div>`}
		</div>
		<div class="preamble__entries-container">
			<div class="preamble__entry">${a}</div>
			<div class="preamble__channel-title">#${i}</div>
			${o?`<div class="preamble__entry preamble__entry--small">${o}</div>`:``}
			<div class="preamble__entry preamble__entry--small">${n(e.rangeDescription||`Exported ${t.length} message(s)`)} • ${s}</div>
		</div>
	</div>

	<main class="chatlog" id="chatStream">
		${x||`<div style="text-align:center; padding:40px; color:var(--text-muted);">No messages found.</div>`}
	</main>

	<div class="postamble">
		<div class="postamble__entry">Exported ${t.length} message(s)</div>
		<div class="postamble__entry">${a} • #${i} • ${s}</div>
	</div>

	<div id="lightbox" class="lightbox-modal" onclick="closeLightbox(event)">
		<div class="lightbox-box">
			<img id="lightboxImg" class="lightbox-img" src="" alt="Preview" />
		</div>
	</div>

	<div class="floating-actions">
		<button class="floating-btn" title="Jump to top" onclick="window.scrollTo({ top: 0, behavior: 'smooth' })">
			<svg viewBox="0 0 24 24"><path d="M7.41 15.41L12 10.83l4.59 4.58L18 14l-6-6-6 6z"/></svg>
		</button>
		<button class="floating-btn" title="Jump to bottom" onclick="window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })">
			<svg viewBox="0 0 24 24"><path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z"/></svg>
		</button>
	</div>

	<script>
		function openLightbox(url) {
			const lb = document.getElementById('lightbox');
			const img = document.getElementById('lightboxImg');
			img.src = url;
			lb.classList.add('active');
		}

		function closeLightbox(e) {
			if (!e || e.target !== document.getElementById('lightboxImg')) {
				const lb = document.getElementById('lightbox');
				lb.classList.remove('active');
				document.getElementById('lightboxImg').src = '';
			}
		}

		document.addEventListener('keydown', function(e) {
			if (e.key === 'Escape') {
				closeLightbox();
			}
		});

		function showSpoiler(event, element) {
			if (!element) return;
			if (element.classList.contains('chatlog__attachment--hidden')) {
				event.preventDefault();
				element.classList.remove('chatlog__attachment--hidden');
			}
			if (element.classList.contains('chatlog__markdown-spoiler--hidden')) {
				event.preventDefault();
				element.classList.remove('chatlog__markdown-spoiler--hidden');
			}
		}

		function scrollToMessage(event, id) {
			const element = document.getElementById('chatlog__message-container-' + id);
			if (!element) return;
			event.preventDefault();
			element.classList.add('chatlog__message-container--highlighted');
			window.scrollTo({
				top: element.getBoundingClientRect().top + window.pageYOffset - (window.innerHeight / 2),
				behavior: 'smooth'
			});
			setTimeout(function() {
				element.classList.remove('chatlog__message-container--highlighted');
			}, 2000);
		}

		function toggleTopic() {
			const panel = document.getElementById('topicPanel');
			if (panel) {
				panel.classList.toggle('collapsed');
			}
		}

		const searchInput = document.getElementById('searchInput');
		const statsBadge = document.getElementById('statsBadge');
		const containers = document.querySelectorAll('.chatlog__message-container');
		const totalCount = containers.length;

		if (searchInput) {
			searchInput.addEventListener('input', function() {
				const query = searchInput.value.toLowerCase().trim();
				let visible = 0;
				containers.forEach(function(c) {
					const text = c.innerText.toLowerCase();
					const match = !query || text.includes(query);
					c.style.display = match ? '' : 'none';
					if (match) visible++;
				});
				statsBadge.innerText = query ? visible + ' / ' + totalCount + ' msgs' : totalCount + ' msgs';
			});
		}
	<\/script>
</body>
</html>`}function F(e,t){if(e){if(Array.isArray(e))return e.find(function(e){return e&&(e.id===t||e.roleId===t)});if(typeof e==`object`){var n=e;return n[t]?n[t]:Object.values(n).find(function(e){return e&&(e.id===t||e.roleId===t)})}}}function I(e){return e.colorString?e.colorString:typeof e.color==`number`&&e.color>0?`#${e.color.toString(16).padStart(6,`0`)}`:e.colorStrings?.primaryColor}function L(e,t){var n=valenced.discord.flux.Stores;if(t){var r=n.GuildRoleStore?.getRole?.(t,e);if(r?.name)return{name:r.name,color:I(r)};var i=n.GuildRoleStore?.getUnsafeMutableRoles?.(t),a=F(i,e);if(a?.name)return{name:a.name,color:I(a)};var o=n.GuildRoleStore?.getRoles?.(t),s=F(o,e);if(s?.name)return{name:s.name,color:I(s)};var c=n.GuildStore?.getGuild?.(t)?.roles,l=F(c,e);if(l?.name)return{name:l.name,color:I(l)}}var u=n.GuildStore?.getGuilds?.();if(u)for(var[d,f]of Object.entries(u)){var p=F(f.roles,e)||n.GuildRoleStore?.getRole?.(d,e)||F(n.GuildRoleStore?.getUnsafeMutableRoles?.(d),e)||F(n.GuildRoleStore?.getRoles?.(d),e);if(p?.name)return{name:p.name,color:I(p)}}}function R(e,t){return e?e.replace(/<@&(\w+)>/g,function(e,n){var r=L(n,t);return r?`@${r.name}`:`@role`}):``}function z(e){if(typeof e.content_type==`string`&&e.content_type.trim())return e.content_type.trim().toLowerCase();if(typeof e.original_content_type==`string`&&e.original_content_type.trim())return e.original_content_type.trim().toLowerCase();var t=(e.filename||``).toLowerCase();return/\.(mp4|webm|mov|m4v|mkv|avi|flv|wmv)$/i.test(t)?`video/mp4`:/\.(png|jpe?g|gif|webp|bmp|svg|tiff?)$/i.test(t)?`image/png`:/\.(mp3|wav|ogg|m4a|aac|opus)$/i.test(t)?`audio/mpeg`:``}function B(e){var t=z(e);if(t.startsWith(`video/`))return!0;var n=(e.filename||``).toLowerCase();return!!(/\.(mp4|webm|mov|m4v|mkv|avi|flv|wmv)$/i.test(n)||(e.width!=null&&e.width>0||e.height!=null&&e.height>0)&&!t.startsWith(`image/`)&&!t.startsWith(`audio/`))}function V(e){if(z(e).startsWith(`image/`))return!0;var t=(e.filename||``).toLowerCase();return!!/\.(png|jpe?g|gif|webp|bmp|svg|tiff?)$/i.test(t)}function ae(e,t){if(B(e)||V(e))return!1;var n=z(e);return e.width!=null&&e.width>0||e.height!=null&&e.height>0?!1:!!(t&&t&8192||(e.flags??0)&8192||e.waveform||e.duration_secs!==void 0&&(n.startsWith(`audio/`)||!n||e.filename.endsWith(`.ogg`)||e.filename.endsWith(`.mp3`)||e.filename.endsWith(`.wav`)))}function H(e){if(!e.reactions||e.reactions.length===0)return[];if(!e.poll)return e.reactions;var t=/* @__PURE__ */ new Set,n=/* @__PURE__ */ new Set;for(var r of e.poll.answers||[])r.poll_media?.emoji?.name&&t.add(r.poll_media.emoji.name),r.poll_media?.emoji?.id&&n.add(r.poll_media.emoji.id);return e.reactions.filter(function(e){return!(e.is_vote||e.emoji?.id&&n.has(e.emoji.id)||e.emoji?.name&&t.has(e.emoji.name)||t.size===0&&n.size===0)})}function U(e){if(e.embeds&&e.embeds.length>0){var t=e.embeds.find(function(e){return e.type===`poll_result`})||e.embeds[0];if(t?.fields&&t.fields.length>0){var n=function(e){var n=t.fields?.find(function(t){return t.name===e||t.rawName===e});return(n?.value??n?.rawValue??``).trim()},r=n(`poll_question_text`),i=n(`victor_answer_text`),a=n(`victor_answer_votes`),o=n(`total_votes`),s=n(`victor_answer_emoji_name`);if(r||i)return{question:r,victorText:i,victorVotes:a,totalVotes:o,emojiName:s||void 0}}}if(e.poll){var c=function(e){var t=d.find(function(t){return t.id===e.answer_id})?.count??0;t>f&&(f=t,p=e)},l=e.poll.question?.text||``,u=e.poll.answers||[],d=e.poll.results?.answer_counts||[],f=-1,p=u[0];for(var m of u)c(m);var h=String(e.poll.results?.total_votes??d.reduce(function(e,t){return e+(t.count||0)},0));return{question:l,victorText:p?.poll_media?.text||``,victorVotes:f>=0?String(f):`0`,totalVotes:h,emojiName:p?.poll_media?.emoji?.name}}return null}function W(e){return e?e.discriminator&&e.discriminator!==`0`?`${e.username}#${e.discriminator}`:e.globalName?`${e.globalName} (@${e.username})`:e.username:`Unknown Author`}function oe(e,t){if(typeof e!=`string`||!e)return``;if(e.startsWith(`attachment://`)){var n=e.slice(13),r=t?.find(function(e){return e.filename===n});if(r)return r.proxy_url||r.url}return e}function G(e,t=`    `,n=0,r){if(!e||n>10)return[];var i=[],a=Number(e.type);if(a===17||e.type===`container`){var o=e.accent_color?` [Color: #${e.accent_color.toString(16).padStart(6,`0`)}]`:``,s=e.spoiler?` (Spoiler)`:``;if(i.push(`${t}[Container${o}${s}]:`),Array.isArray(e.components))for(var c of e.components)i.push(...G(c,`${t}  `,n+1,r));return i}if(a===9||e.type===`section`){if(i.push(`${t}[Section]:`),Array.isArray(e.components))for(var l of e.components)i.push(...G(l,`${t}  `,n+1,r));return e.accessory&&(i.push(`${t}  Accessory:`),i.push(...G(e.accessory,`${t}    `,n+1,r))),i}if(a===10||e.type===`text_display`)return e.content&&i.push(`${t}• ${e.content}`),i;if(a===1||e.type===`action_row`){if(Array.isArray(e.components))for(var u of e.components)i.push(...G(u,t,n+1,r));return i}if(a===2||e.type===`button`){var d=e.label||``,f=e.url?` -> ${e.url}`:``,p=e.disabled?` (Disabled)`:``;return i.push(`${t}[Button: ${d}${f}${p}]`),i}if(a===3||a===5||a===6||a===7||a===8||e.type===`select`){var m=e.placeholder||`Select...`,h=e.options?.map(function(e){return e.label||e.value}).join(`, `),g=h?` (${h})`:``;return i.push(`${t}[Select: ${m}${g}]`),i}if(a===11||e.type===`thumbnail`){var _=oe(e.media?.url||(typeof e.media==`string`?e.media:``)||e.url||``,r);return i.push(`${t}[Thumbnail: ${_}]`),i}if(a===12||e.type===`media_gallery`){var v=e.items?.map(function(e){return oe(e.media?.url||(typeof e.media==`string`?e.media:``)||e.url||``,r)}).filter(Boolean).join(`, `);return i.push(`${t}[Media Gallery: ${v}]`),i}if(a===13||e.type===`file`){var y=e.file?.url||e.url||``,b=e.filename||e.file?.filename||`File`;if(y.startsWith(`attachment://`)){var x=y.slice(13),S=r?.find(function(e){return e.filename===x});S&&(y=S.proxy_url||S.url,!e.filename&&!e.file?.filename&&(b=S.filename))}return i.push(`${t}[File: ${b}${y?` (${y})`:``}]`),i}return(a===14||e.type===`separator`)&&i.push(`${t}---`),i}function K(e){var t=Number(e.type??0);if(t===0||t===19||t===20||t===23||e.messageSnapshots&&e.messageSnapshots.length>0||e.message_snapshots&&e.message_snapshots.length>0)return null;if(t===1){var n=e.mentions?.[0],r=n?n.globalName||n.global_name||n.username:``;return r?`added ${r} to the group.`:`added a recipient to the group.`}if(t===2){var i=e.mentions?.[0],a=i?i.globalName||i.global_name||i.username:``;return a?`removed ${a} from the group.`:`removed a recipient from the group.`}if(t===3){var o=e.call?.duration?Math.max(1,Math.round(e.call.duration/60)):0;return o>0?`started a call that lasted ${o} min.`:`started a call.`}if(t===4)return e.content?`changed the channel name: ${e.content}`:`changed the channel name.`;if(t===5)return`changed the channel icon.`;if(t===6)return`pinned a message to this channel.`;if(t===7)return`joined the server.`;if(t===8)return`boosted the server!`;if(t>=9&&t<=11)return`boosted the server to Tier ${t-7}!`;if(t===12)return`added a channel follow to this channel.`;if(t===18)return e.content?`started a thread: ${e.content}`:`started a thread.`;if(t===21)return`started a thread starter message.`;if(t===22)return`reminded the server about guild invites.`;if(t===24)return`AutoMod caught a message.`;if(t===25)return`subscribed to the server.`;if(t===27)return`started a stage.`;if(t===28)return`ended a stage.`;if(t===29)return`became a speaker in the stage.`;if(t===31)return e.content?`changed the stage topic: ${e.content}`:`changed the stage topic.`;if(t===32)return`added an integration to this channel.`;if(t===36||t===44)return`purchased an item from the server shop.`;if(t===46){var s=U(e);if(s){var c=s.emojiName?`${s.emojiName} `:``,l=s.totalVotes?`(${s.victorVotes}/${s.totalVotes} votes)`:`(${s.victorVotes} votes)`;return`Poll "${s.question}" ended. Winner: ${c}${s.victorText} ${l}`}return`poll ended.`}return`system action performed.`}function q(e,t,n,r=`  `,i=0,a){if(!(!Array.isArray(e)||e.length===0||i>5)){t.push(`${r}[Forwarded Message]:`);for(var o of e){var s=o?.message??o,c=`${r}  `;if(n.includeTimestamps&&s.timestamp){var l=new Date(s.timestamp);Number.isNaN(l.getTime())||(c+=`[${l.toLocaleString()}] `)}s.author?.username&&s.author.username!==`Unknown`&&(c+=`${W(s.author)}: `);var u=R(s.content??``,a);if((s.editedTimestamp||s.edited_timestamp)&&(u+=` (edited)`),(u||s.author?.username||c.trim())&&t.push(`${c}${u}`.trimEnd()),n.includeAttachments&&s.attachments&&s.attachments.length>0){t.push(`${r}    Attachments:`);for(var d of s.attachments){var f=d.size?` (${(d.size/1024).toFixed(1)} KB)`:``,p=ae(d,s.flags)?` [Voice Message]`:``,m=d.url||d.proxy_url||``;t.push(`${r}      - ${d.filename}${p}${f}: ${m}`)}}if(n.includeEmbeds&&s.embeds&&s.embeds.length>0){t.push(`${r}    Embeds:`);for(var h of s.embeds)if(h.title&&t.push(`${r}      - Title: ${h.title}`),h.url&&t.push(`${r}        URL: ${h.url}`),h.description&&t.push(`${r}        Description: ${R(h.description,a)}`),h.fields&&h.fields.length>0)for(var g of h.fields)t.push(`${r}        • ${g.name??g.rawName??``}: ${R(g.value??g.rawValue??``,a)}`)}if((n.includeComponents??!0)&&s.components&&s.components.length>0){t.push(`${r}    Components:`);for(var _ of s.components)t.push(...G(_,`${r}      `,0,s.attachments))}if(s.poll){var v=function(e){var n=s.poll.results?.answer_counts?.find(function(t){return t.id===e.answer_id})?.count??0,i=e.poll_media?.emoji?.name?`${e.poll_media.emoji.name} `:``;t.push(`${r}      - ${i}${e.poll_media?.text??``} (${n} votes)`)};t.push(`${r}    [Poll]: ${s.poll.question?.text??`Poll`}`);for(var y of s.poll.answers||[])v(y)}var b=s.stickerItems||s.stickers||s.sticker_items;if(Array.isArray(b)&&b.length>0)for(var x of b)t.push(`${r}    [Sticker: ${x.name}]`);var S=s.messageSnapshots||s.message_snapshots;Array.isArray(S)&&S.length>0&&q(S,t,n,`${r}    `,i+1,a)}}}function J(e,t){var n=K(e);if(n){var r=``;if(t.includeTimestamps&&e.timestamp){var i=new Date(e.timestamp);Number.isNaN(i.getTime())||(r=`[${i.toLocaleString()}] `)}return`${r}[System]: ${W(e.author)} ${n}`}var a=[],o=``;if(t.includeTimestamps&&e.timestamp){var s=new Date(e.timestamp);Number.isNaN(s.getTime())||(o+=`[${s.toLocaleString()}] `)}e.pinned&&(o+=`[Pinned] `),o+=W(e.author);var c=e.interactionMetadata?.name||e.interaction?.name;c&&(o+=` [Used /${c}]`),o+=`:`;var l=e.channel_id?valenced.discord.flux.Stores?.ChannelStore?.getChannel?.(e.channel_id)?.guild_id:void 0,u=R(e.content??``,l);(e.editedTimestamp||e.edited_timestamp)&&(u+=` (edited)`),a.push(`${o} ${u}`.trimEnd());var d=!!(e.messageSnapshots&&e.messageSnapshots.length>0||e.message_snapshots&&e.message_snapshots.length>0||e.messageReference?.type===1);if(e.referencedMessage&&!d){var f=W(e.referencedMessage.author),p=e.referencedMessage.content?e.referencedMessage.content.slice(0,60):e.referencedMessage.attachments?.length?`Attachment`:`Message`;a.push(`  [Replying to ${f}: ${p}]`)}if(t.includeAttachments&&e.attachments&&e.attachments.length>0){a.push(`  Attachments:`);for(var m of e.attachments){var h=m.size?` (${(m.size/1024).toFixed(1)} KB)`:``,g=ae(m,e.flags)?` [Voice Message]`:``,_=m.url||m.proxy_url||``;a.push(`    - ${m.filename}${g}${h}: ${_}`)}}var v=!!(e.flags&&e.flags&4);if(t.includeEmbeds&&!v&&e.embeds&&e.embeds.length>0){a.push(`  Embeds:`);for(var y of e.embeds)if(y.title&&a.push(`    - Title: ${y.title}`),y.url&&a.push(`      URL: ${y.url}`),y.description&&a.push(`      Description: ${R(y.description,l)}`),y.fields&&y.fields.length>0)for(var b of y.fields)a.push(`      • ${b.name??b.rawName??``}: ${R(b.value??b.rawValue??``,l)}`)}if((t.includeComponents??!0)&&e.components&&e.components.length>0){a.push(`  Components:`);for(var x of e.components)a.push(...G(x,`    `,0,e.attachments))}if(e.poll){var S=function(t){var n=e.poll.results?.answer_counts?.find(function(e){return e.id===t.answer_id})?.count??0,r=t.poll_media?.emoji?.name?`${t.poll_media.emoji.name} `:``;a.push(`    - ${r}${t.poll_media?.text??``} (${n} votes)`)};a.push(`  [Poll]: ${e.poll.question?.text??`Poll`}`);for(var C of e.poll.answers||[])S(C)}var w=e.stickerItems||e.stickers||e.sticker_items;if(Array.isArray(w)&&w.length>0)for(var T of w)a.push(`  [Sticker: ${T.name}]`);var E=H(e);if(E.length>0){var D=E.map(function(e){return`${e.emoji.name} (${e.count})`}).join(`, `);a.push(`  Reactions: ${D}`)}var O=e.messageSnapshots||e.message_snapshots;return Array.isArray(O)&&O.length>0&&q(O,a,t,`  `,0,l),a.join(`
`)}function se(e,t,n){var r=[`# Chat Export: ${n.name}`,n.guildName?`Server: ${n.guildName}`:``,n.topic?`Topic: ${n.topic}`:``,`Exported At: ${n.exportedAt}`,`Total Messages: ${e.length}`,`=`.repeat(50),``].filter(Boolean);for(var i of e)r.push(J(i,t)),r.push(``);return r.join(`
`)}function Y(e,t=/* @__PURE__ */ new WeakSet,n=0){if(!(n>10||e===void 0)){if(typeof e!=`object`||!e)return e;if(t.has(e))return`[Circular]`;if(t.add(e),Array.isArray(e))return e.map(function(e){return Y(e,t,n+1)}).filter(function(e){return e!==void 0});var r={};for(var[i,a]of Object.entries(e))typeof a!=`function`&&(r[i]=typeof a==`object`&&a?Y(a,t,n+1):a);return r}}function ce(e,t){var n={id:e.id,channel_id:e.channel_id,type:e.type??0,author:{id:e.author.id,username:e.author.username,discriminator:e.author.discriminator,globalName:e.author.globalName,bot:e.author.bot,avatar:e.author.avatar},content:e.content??``,pinned:!!e.pinned};e.flags!==void 0&&(n.flags=e.flags),t.includeTimestamps&&e.timestamp&&(n.timestamp=e.timestamp);var r=e.editedTimestamp??e.edited_timestamp;t.includeTimestamps&&r&&(n.editedTimestamp=r),e.messageReference&&(n.messageReference=e.messageReference);var i=e.interactionMetadata||e.interaction;i&&(n.interaction=i),t.includeAttachments&&e.attachments&&(n.attachments=e.attachments.map(function(e){return{filename:e.filename,url:e.url,proxy_url:e.proxy_url,size:e.size,contentType:e.content_type,duration_secs:e.duration_secs}})),t.includeEmbeds&&e.embeds&&(n.embeds=e.embeds.map(function(e){return{title:e.title,description:e.description,url:e.url,fields:e.fields,color:e.color}})),(t.includeComponents??!0)&&e.components&&e.components.length>0&&(n.components=Y(e.components)),e.poll&&(n.poll=Y(e.poll));var a=e.stickerItems||e.stickers||e.sticker_items;Array.isArray(a)&&a.length>0&&(n.stickerItems=a);var o=H(e);o.length>0&&(n.reactions=o);var s=e.messageSnapshots||e.message_snapshots;return Array.isArray(s)&&s.length>0&&(n.messageSnapshots=Y(s)),JSON.stringify(n,null,2)}function le(e,t,n){var r={meta:n,messages:e.map(function(e){return JSON.parse(ce(e,t))})};return JSON.stringify(r,null,2)}function ue(e,t){return t.format===`html`?P({id:e.channel_id??`0`,name:`Message Export`,totalMessages:1,exportedAt:(/* @__PURE__ */ new Date()).toISOString()},[e],t):t.format===`json`?ce(e,t):J(e,t)}function X(e,t,n){return t.format===`html`?P(n,e,t):t.format===`json`?le(e,t,n):se(e,t,n)}function Z(e,t=`success`){try{if(typeof valenced.discord.actions.ToastActionCreators?.open==`function`){if(valenced.discord.actions.ToastActionCreators.open.length===1){var n=valenced.discord.actions.ToastActionCreators.open;n({key:`hieuxyz-export-messages`,text:e,variant:t})}else valenced.discord.actions.ToastActionCreators.open(`hieuxyz-export-messages`,{text:e,variant:t})}}catch{}}function de(){try{var e=valenced?.hieuxyz;return typeof e?.saf?.isSafAvailable==`function`&&e.saf.isSafAvailable()}catch{return!1}}function fe(e){return e.endsWith(`.html`)?`text/html`:e.endsWith(`.json`)?`application/json`:`text/plain`}async function pe(e,t,n){if(t===`clipboard`)valenced.externals.ReactNativeClipboard.Clipboard.setString(e),Z(`Copied to clipboard!`,`success`);else{if(t===`saf`&&de())try{var r=fe(n);if(await(valenced?.hieuxyz)?.saf?.saveViaSaf?.(n,r,e)){Z(`Save file dialog opened.`,`success`);return}}catch{}if(valenced.react.ReactNative.Platform.OS===`ios`)try{var i=valenced.modules.native.fs.getConstants();if(i?.cache){var a=`${i.cache}/${n}`;if(await valenced.modules.native.fs.writeFile(a,e),valenced.react.ReactNative?.Share?.share){await valenced.react.ReactNative.Share.share({url:`file://${a}`,title:n}),Z(`Shared successfully!`,`success`);return}}}catch{}try{valenced.react.ReactNative?.Share?.share?(await valenced.react.ReactNative.Share.share({message:e,title:n}),Z(`Shared successfully!`,`success`)):(valenced.externals.ReactNativeClipboard.Clipboard.setString(e),Z(`Share unavailable, copied to clipboard instead.`,`default`))}catch{valenced.externals.ReactNativeClipboard.Clipboard.setString(e),Z(`Export failed, copied to clipboard instead.`,`critical`)}}}async function me(e,t,n,r){var i;if(t.format===`html`){var a=e.channel_id,{channelName:o,guildName:s,guildIconUrl:c,topic:l}=$(a),u={id:a??`0`,name:o,guildName:s,guildIconUrl:c,topic:l,totalMessages:1,exportedAt:(/* @__PURE__ */ new Date()).toISOString(),rangeDescription:`Single Message ID ${e.id}`};i=X([e],t,u)}else i=ue(e,t);var d=t.format===`html`?`html`:t.format===`json`?`json`:`txt`,f=r?.trim()||`discord_msg_${e.id}.${d}`;await pe(i,n,f)}async function Q(e,t,n=`before`){var r=valenced.discord.flux.Stores.MessageStore,i=r?.getMessages?.(e),a=i?.toArray?.()??i?._array??[];if(a.length>=t)return a;var[o]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`sendMessage`,`fetchMessages`));if(!o?.fetchMessages)return a;var s=0,c=20;for(Z(`Loading messages (${a.length}/${t})...`,`default`);a.length<t&&(n===`before`&&i?.hasMoreBefore||n===`after`&&i?.hasMoreAfter)&&s<c;){s++;var l=Math.min(50,t-a.length);if(n===`before`){var u=a[0];if(!u?.id)break;o.fetchMessages({channelId:e,before:u.id,limit:l})}else{var d=a[a.length-1];if(!d?.id)break;o.fetchMessages({channelId:e,after:d.id,limit:l})}await new Promise(function(e){return setTimeout(e,650)}),i=r?.getMessages?.(e);var f=i?.toArray?.()??i?._array??[];if(f.length===a.length){await new Promise(function(e){return setTimeout(e,650)}),i=r?.getMessages?.(e);var p=i?.toArray?.()??i?._array??[];if(p.length===a.length)break;a=p}else a=f}return a}function $(e){var t=valenced.discord.flux.Stores.SelectedChannelStore,n=valenced.discord.flux.Stores.ChannelStore,r=valenced.discord.flux.Stores.GuildStore,i=valenced.discord.flux.Stores.MessageStore,a=e??t?.getChannelId?.();if(!a)return{messages:[],channelName:`Chat`};var o=i?.getMessages?.(a),s=o?.toArray?.()??o?._array??[],c=n?.getChannel?.(a),l=c?.guild_id?r?.getGuild?.(c.guild_id):void 0,u=l?.id&&l?.icon?`https://cdn.discordapp.com/icons/${l.id}/${l.icon}.png?size=128`:void 0;return{messages:s,channelName:c?.name??`Direct Message`,guildName:l?.name,guildIconUrl:u,topic:c?.topic}}async function he(e,t,n,r,i){var a=valenced.discord.flux.Stores.SelectedChannelStore,o=e??a?.getChannelId?.();if(!o)Z(`No active channel found.`,`critical`);else{var s;if(typeof t==`number`&&t>0)s=await Q(o,t);else{var{messages:c}=$(o);s=c}if(s.length===0)Z(`No loaded messages found in this channel.`,`default`);else{var l=s;typeof t==`number`&&t>0&&t<s.length&&(l=s.slice(-t));var{channelName:u,guildName:d,guildIconUrl:f,topic:p}=$(o),m=u.replace(/[^a-zA-Z0-9_-]/g,`_`),h=n.format===`html`?`html`:n.format===`json`?`json`:`txt`,g=`discord_${m}_${Date.now()}.${h}`,_=i?.trim()||g,v={id:o,name:u,guildName:d,guildIconUrl:f,topic:p,totalMessages:l.length,exportedAt:(/* @__PURE__ */ new Date()).toISOString(),rangeDescription:typeof t==`number`?`Last ${l.length} message(s)`:`All ${l.length} message(s)`};await pe(X(l,n,v),r,_)}}}async function ge(e,t,n,r,i,a,o){var s=valenced.discord.flux.Stores.SelectedChannelStore,c=e??t.channel_id??s?.getChannelId?.();if(!c)Z(`No active channel found.`,`critical`);else{var{channelName:l,guildName:u,guildIconUrl:d,topic:f}=$(c),p=valenced.discord.flux.Stores.MessageStore,m,h;if(n===`before`){var g=p?.getMessages?.(c),_=g?.toArray?.()??g?._array??[],v=_.findIndex(function(e){return e.id===t.id});if(typeof r==`number`&&r>0){var y=v===-1?_.length:v+1;if(y<r&&g?.hasMoreBefore){var b=r-y;m=await Q(c,_.length+b,`before`)}else m=_}else m=r===`all`?await Q(c,Math.max(500,_.length+50),`before`):_;var x=m.findIndex(function(e){return e.id===t.id}),S=x===-1?m.length:x+1;h=typeof r==`number`&&r>0&&r<S?m.slice(S-r,S):m.slice(0,S)}else{var C=p?.getMessages?.(c),w=C?.toArray?.()??C?._array??[],T=w.findIndex(function(e){return e.id===t.id});if(typeof r==`number`&&r>0){var E=T===-1?w.length:w.length-T;if(E<r&&C?.hasMoreAfter){var D=r-E;m=await Q(c,w.length+D,`after`)}else m=w}else m=w;var O=m.findIndex(function(e){return e.id===t.id}),k=O===-1?0:O;h=typeof r==`number`&&r>0?m.slice(k,k+r):m.slice(k)}if(h.length===0)Z(`No messages matched the export range.`,`default`);else{var A=l.replace(/[^a-zA-Z0-9_-]/g,`_`),j=i.format===`html`?`html`:i.format===`json`?`json`:`txt`,M=`discord_${A}_${n}_${t.id}.${j}`,ee=o?.trim()||M,te={id:c,name:l,guildName:u,guildIconUrl:d,topic:f,totalMessages:h.length,exportedAt:(/* @__PURE__ */ new Date()).toISOString(),rangeDescription:n===`before`?`Exported ${h.length} message(s) before message ${t.id}`:`Exported ${h.length} message(s) after message ${t.id}`};await pe(X(h,i,te),a,ee)}}}function _e({alertKey:e=`valenced-export-dialog`,initialMessage:n,initialChannelId:r,settings:i}){valenced.discord.actions.AlertActionCreators.openAlert(e,/*#__PURE__*/ (0,t.jsx)(ve,{alertKey:e,initialMessage:n,initialChannelId:r,settings:i}))}function ve({alertKey:e,initialMessage:n,initialChannelId:r,settings:i}){var a=de(),[o,s]=valenced.react.React.useState(n?`message`:`channel`),[c,l]=valenced.react.React.useState(i.format??`html`),[u,d]=valenced.react.React.useState(a?i.destination??`saf`:`share`),{messages:f,channelName:p}=$(r??n?.channel_id),m=p.replace(/[^a-zA-Z0-9_-]/g,`_`),[h,g]=valenced.react.React.useState(`all`),_=c===`html`?`html`:c===`json`?`json`:`txt`,v=o===`message`?`discord_msg_${n?.id??Date.now()}`:o===`before`?`discord_${m}_before_${n?.id??Date.now()}`:o===`after`?`discord_${m}_after_${n?.id??Date.now()}`:`discord_${m}_${Date.now()}`,[y,b]=valenced.react.React.useState(`${v}.${_}`);return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.AlertModal,{title:`Export Chat`,content:`Customize your export options below:`,extraContent:/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.ScrollView,{style:{maxHeight:380},showsVerticalScrollIndicator:!1,children:/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{gap:12,paddingVertical:4},children:[n&&/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRadioGroup,{title:`Export Target`,value:o,onChange:function(e){s(e);var t=`discord_${m}_${Date.now()}`;e===`message`?t=`discord_msg_${n.id}`:e===`before`?t=`discord_${m}_before_${n.id}`:e===`after`&&(t=`discord_${m}_after_${n.id}`),b(`${t}.${_}`)},children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`This Message Only`,subLabel:`Export only the selected message.`,value:`message`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`From Selected Message Backwards`,subLabel:`Export from this message back into older history.`,value:`before`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`From Selected Message Forwards`,subLabel:`Export from this message forward into newer history.`,value:`after`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Channel Chat History`,subLabel:`Export history from #${p} (${f.length} messages loaded).`,value:`channel`})]}),o!==`message`&&/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRowGroup,{title:`Message Count`,children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableSwitchRow,{label:o===`before`?`Export All Older Messages`:o===`after`?`Export All Newer Messages`:`Export All Loaded Messages`,subLabel:o===`before`?`Exports all available messages before this message.`:o===`after`?`Exports all available messages after this message.`:`Exports all ${f.length} currently loaded messages.`,value:h===`all`,onValueChange:function(e){g(e?`all`:`50`)}}),h!==`all`&&/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{paddingHorizontal:16,paddingVertical:8},children:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TextInput,{label:`Target Message Count`,placeholder:`e.g. 50, 100, 200 (fetches more if needed)`,value:h,onChange:function(e){g(e.replace(/[^0-9]/g,``))}})})]}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRadioGroup,{title:`Export Format`,value:c,onChange:function(e){l(e);var t=e===`html`?`html`:e===`json`?`json`:`txt`;b(function(e){var n=e.lastIndexOf(`.`);return n===-1?`${e}.${t}`:`${e.slice(0,n)}.${t}`})},children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Discord HTML (Recommended)`,subLabel:`Standalone offline chat viewer with avatars, markdown, attachments, and search.`,value:`html`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`JSON`,subLabel:`Structured data with raw message objects.`,value:`json`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Plain Text`,subLabel:`Simple formatted text transcript.`,value:`text`})]}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRadioGroup,{title:`Save Destination`,value:u,onChange:function(e){return d(e)},children:[a&&/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Save to Device (SAF)`,subLabel:`Opens Android document picker to choose folder and custom file name.`,value:`saf`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`System Share Sheet`,subLabel:`Share to other apps (Drive, Telegram, etc.).`,value:`share`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Copy to Clipboard`,subLabel:`Copies output directly to clipboard.`,value:`clipboard`})]}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRowGroup,{title:`File Name`,children:/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{paddingHorizontal:16,paddingVertical:8},children:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TextInput,{label:`Output File Name`,placeholder:`e.g. discord_chat.html`,value:y,onChange:function(e){return b(e)}})})})]})}),actions:/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.AlertActionButton,{text:`Export`,variant:`primary`,onPress:function(){valenced.discord.actions.AlertActionCreators.dismissAlert(e);var t={...i,format:c,destination:u};if(o===`message`&&n)me(n,t,u,y);else{var a=h===`all`?`all`:Math.max(1,Number.parseInt(h,10)||f.length);(o===`before`||o===`after`)&&n?ge(r??n.channel_id,n,o,a,t,u,y):he(r??n?.channel_id,a,t,u,y)}}}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.AlertActionButton,{text:`Cancel`,onPress:function(){return valenced.discord.actions.AlertActionCreators.dismissAlert(e)}})]})})}var ye={destination:`saf`,format:`html`,includeAttachments:!0,includeEmbeds:!0,includeTimestamps:!0,includeComponents:!0};function be(e){if(typeof e!=`object`||!e||!(`props`in e))return!1;var t=e.props;if(typeof t!=`object`||!t)return!1;var n=t,r=typeof n.label==`string`||typeof n.message==`string`,i=typeof n.onPress==`function`||typeof n.onPressRow==`function`;return r&&i}function xe(e,t=0){if(!(typeof e!=`object`||!e||t>15)){if(Array.isArray(e))for(var n of e){var r=xe(n,t+1);if(r)return r}else if(`props`in e){var i=e.props;if(typeof i==`object`&&i){var a=i,o=a.children;if(Array.isArray(o)){if(o.some(be))return o;for(var s of o){var c=xe(s,t+1);if(c)return c}}else if(o){if(be(o)){var l=[o];return a.children=l,l}return xe(o,t+1)}}}}}var Se=`hieuxyz-export-chat-row`;function Ce(e,t){var n,r=valenced.patcher.before(valenced.discord.actions.ActionSheetActionCreators,`openLazy`,function(r){var[i,a,o]=r;if(a!==`MessageLongPressActionSheet`&&a!==`MessageActionSheet`)return r;var s=o,c=s?.message;return c?.id&&i.then(function(r){if(typeof r==`object`&&r&&`default`in r){var i=r;if(typeof i.default==`function`){n?.();var a=valenced.patcher.after(i,`default`,function(e){if(!e)return e;var n=xe(e);if(!n||n.some(function(e){return typeof e==`object`&&!!e&&`key`in e&&e.key===Se}))return e;var r=n.find(be);if(!r)return e;var i={...ye,...t.cache},a=c.channel_id??s?.channel?.id,o=function(e,t,n,i){var a=r.props.onPressRow?{key:e,message:t,onPressRow:n,icon:i}:{key:e,label:t,onPress:n,icon:i};return valenced.react.React.createElement(r.type,a)},l=r.type.Icon??valenced.discord.design.Design.ActionSheetRow?.Icon,u=valenced.utils.discord.lookupGeneratedIconComponent(`ShareIcon`,`DownloadIcon`,`ChatIcon`),d;if(l){if(u)d=valenced.react.React.createElement(l,{IconComponent:u});else try{var f=valenced.assets.getAssetIdByName(`ShareIcon`)??valenced.assets.getAssetIdByName(`DownloadIcon`)??valenced.assets.getAssetIdByName(`ic_share`);f!==void 0&&(d=valenced.react.React.createElement(l,{source:f}))}catch{}}var p=Math.min(1,n.length),m=o(Se,`Export Chat`,function(){valenced.discord.actions.ActionSheetActionCreators.hideActionSheet(),_e({alertKey:`valenced-export-chat-dialog`,initialMessage:c,initialChannelId:a,settings:i})},d);return n.splice(p,0,m),e});n=a,e(a)}}}),r});e(function(){r(),n?.(),n=void 0})}function we({api:e}){var n=e.jsonStorage,r=n.use(),i=de(),a={...ye,destination:i?`saf`:`share`,...r};return/*#__PURE__*/ (0,t.jsx)(valenced.components.Page,{children:/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.ScrollView,{showsVerticalScrollIndicator:!1,contentContainerStyle:{paddingBottom:32},children:/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{gap:8},children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRowGroup,{title:`Quick Actions`,children:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRow,{label:`Export Active Channel...`,subLabel:`Open export dialog to customize format, count, file name, and destination for current channel.`,trailing:/*#__PURE__*/ (0,t.jsx)(valenced.components.TableRowAssetIcon,{name:`ChatIcon`}),onPress:function(){var e=valenced.discord.flux.Stores.SelectedChannelStore?.getChannelId?.();_e({alertKey:`valenced-settings-export-dialog`,initialChannelId:e,settings:a})}})}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRadioGroup,{title:`Default Export Format`,value:a.format,onChange:function(e){n.set({format:e})},children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Discord HTML (Recommended)`,subLabel:`Standalone offline chat viewer with avatars, markdown, attachments, and live search.`,value:`html`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Structured JSON`,subLabel:`Machine-readable JSON data with complete message objects.`,value:`json`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Plain Text`,subLabel:`Simple formatted text transcript.`,value:`text`})]}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRadioGroup,{title:`Default Destination`,value:!i&&a.destination===`saf`?`share`:a.destination,onChange:function(e){n.set({destination:e})},children:[i&&/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Save to Device (SAF)`,subLabel:`Opens Android document picker to choose folder and custom file name (requires Hieuxyz Lib).`,value:`saf`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`System Share Sheet`,subLabel:`Share to other apps (Drive, Telegram, file managers, etc.).`,value:`share`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Copy to Clipboard`,subLabel:`Directly copies exported content to your clipboard.`,value:`clipboard`})]}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRowGroup,{title:`Content Options`,children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableSwitchRow,{label:`Include Timestamps`,subLabel:`Include message creation timestamps.`,value:a.includeTimestamps,onValueChange:function(e){n.set({includeTimestamps:e})}}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableSwitchRow,{label:`Include Attachments`,subLabel:`Render image, video, audio, and file attachment cards.`,value:a.includeAttachments,onValueChange:function(e){n.set({includeAttachments:e})}}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableSwitchRow,{label:`Include Embeds`,subLabel:`Render rich embeds with titles, descriptions, and fields.`,value:a.includeEmbeds,onValueChange:function(e){n.set({includeEmbeds:e})}}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableSwitchRow,{label:`Include Components`,subLabel:`Render interactive buttons, select menus, containers, and v2 components.`,value:a.includeComponents??!0,onValueChange:function(e){n.set({includeComponents:e})}})]})]})})})}return e.default=plugin({jsonStorage:{load:!0,default:ye},start({cleanup:e,jsonStorage:t}){Ce(e,t)},SettingsComponent:we}),e})({},valenced.react.ReactJSXRuntime);
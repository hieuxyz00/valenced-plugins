(function(e,t){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});function n(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#39;`)}function r(e,t=`f`){var n=Number.parseInt(e,10);if(Number.isNaN(n)||n<=0)return e;var r=/* @__PURE__ */ new Date(n*1e3),i=Date.now(),a=Math.round((n*1e3-i)/1e3);if(t===`R`){var o=new Intl.RelativeTimeFormat(void 0,{numeric:`auto`}),s=Math.abs(a);return s<60?o.format(a,`second`):s<3600?o.format(Math.round(a/60),`minute`):s<86400?o.format(Math.round(a/3600),`hour`):o.format(Math.round(a/86400),`day`)}return t===`t`?r.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`}):t===`T`?r.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`,second:`2-digit`}):t===`d`?r.toLocaleDateString():t===`D`?r.toLocaleDateString([],{day:`numeric`,month:`long`,year:`numeric`}):t===`F`?`${r.toLocaleDateString([],{weekday:`long`,day:`numeric`,month:`long`,year:`numeric`})} ${r.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})}`:`${r.toLocaleDateString([],{day:`numeric`,month:`long`,year:`numeric`})} ${r.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})}`}function i(e,t,i){if(!e)return``;var a=[],o=function(e){var t=a.length;return a.push(e),`\u0000TOK_${t}\u0000`},s=n(e),c=!!e.trim().match(/^(?:<(?:a)?:[a-zA-Z0-9_]+:\d+>\s*){1,5}$/);s=s.replace(/```(?:([a-zA-Z0-9_-]+)\n)?([\s\S]*?)```/g,function(e,t,n){return o(`<code class="chatlog__markdown-pre chatlog__markdown-pre--multiline${t?` language-${t}`:` nohighlight`}">${n.trim()}</code>`)}),s=s.replace(/`([^`\n]+)`/g,function(e,t){return o(`<code class="chatlog__markdown-pre chatlog__markdown-pre--inline">${t}</code>`)}),s=s.replace(/&lt;(a)?:([a-zA-Z0-9_]+):(\d+)&gt;/g,function(e,t,n,r){var i=`https://cdn.discordapp.com/emojis/${r}.${t?`gif`:`webp`}?size=64&quality=lossless`;return o(`<img class="chatlog__emoji${c?` chatlog__emoji--large`:``}" src="${i}" alt=":${n}:" title=":${n}:" loading="lazy" />`)}),s=s.replace(/(https?:\/\/[^\s<]+)/g,function(e,t){return o(`<a href="${t}" target="_blank" rel="noopener noreferrer">${t}</a>`)}),s=s.replace(/&lt;t:(\d+)(?::([tTdDfFR]))?&gt;/g,function(e,t,n){var i=r(t,n||`f`);return o(`<span class="chatlog__markdown-timestamp" title="${(/* @__PURE__ */ new Date(Number.parseInt(t,10)*1e3)).toLocaleString()}">${i}</span>`)}),s=s.replace(/&lt;@!?(\d+)&gt;/g,function(e,r){var i=t.get(r);if(!i){var a=valenced.discord.flux.Stores.UserStore?.getUser?.(r);a&&(i=a.globalName||a.username,t.set(r,i))}var s=i?`@${i}`:`@User (${r.slice(-4)})`;return o(`<span class="chatlog__markdown-mention" title="${n(i||r)}">${n(s)}</span>`)}),s=s.replace(/&lt;#(\d+)&gt;/g,function(e,t){var r=i.get(t);if(!r){var a=valenced.discord.flux.Stores.ChannelStore?.getChannel?.(t);a&&(r=a.name,i.set(t,r))}return o(`<span class="chatlog__markdown-mention">${n(r?`#${r}`:`#channel`)}</span>`)}),s=s.replace(/&lt;@&amp;(\d+)&gt;/g,`<span class="chatlog__markdown-mention">@role</span>`),s=s.replace(/@everyone/g,`<span class="chatlog__markdown-mention">@everyone</span>`),s=s.replace(/@here/g,`<span class="chatlog__markdown-mention">@here</span>`),s=s.replace(/\|\|([\s\S]*?)\|\|/g,`<span class="chatlog__markdown-spoiler chatlog__markdown-spoiler--hidden" onclick="showSpoiler(event, this)">$1</span>`),s=s.replace(/^### (.*)$/gm,`<h3>$1</h3>`),s=s.replace(/^## (.*)$/gm,`<h2>$1</h2>`),s=s.replace(/^# (.*)$/gm,`<h1>$1</h1>`),s=s.replace(/^-# (.*)$/gm,`<div class="chatlog__markdown-subtext">$1</div>`),s=s.replace(/^&gt;&gt;&gt;\s*([\s\S]*)$/m,`<div class="chatlog__markdown-quote"><div class="chatlog__markdown-quote-border"></div><div class="chatlog__markdown-quote-content">$1</div></div>`),s=s.replace(/^&gt;\s?(.*)$/gm,`<div class="chatlog__markdown-quote"><div class="chatlog__markdown-quote-border"></div><div class="chatlog__markdown-quote-content">$1</div></div>`),s=s.replace(/\*\*([^*]+)\*\*/g,`<strong>$1</strong>`),s=s.replace(/__([^_]+)__/g,`<u>$1</u>`),s=s.replace(/\*([^*]+)\*/g,`<em>$1</em>`),s=s.replace(/(^|\s)_([^_]+)_(\s|$)/g,`$1<em>$2</em>$3`),s=s.replace(/~~([^~]+)~~/g,`<s>$1</s>`),s=s.replace(/\n/g,`<br>`);for(var l=a.length-1;l>=0;l--)s=s.replaceAll(`\u0000TOK_${l}\u0000`,a[l]);return s}function a(e,t=0){if(e?.id&&e?.avatar){var n=e.avatar.startsWith(`a_`)?`gif`:`webp`;return`https://cdn.discordapp.com/avatars/${e.id}/${e.avatar}.${n}?size=128`}return`https://cdn.discordapp.com/embed/avatars/${t%6}.png`}function o(e){return!e||e<=0?``:e<1024?`${e} B`:e<1048576?`${(e/1024).toFixed(1)} KB`:`${(e/1048576).toFixed(1)} MB`}function s(e){var t=n(e.filename),r=n(e.url),i=o(e.size),a=e.filename.toLowerCase(),s=/\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(a)||e.content_type?.startsWith(`image/`),c=/\.(mp4|webm|mov|m4v)$/i.test(a)||e.content_type?.startsWith(`video/`),l=/\.(mp3|wav|ogg|m4a|aac)$/i.test(a)||e.content_type?.startsWith(`audio/`),u=e.filename.startsWith(`SPOILER_`);return s?`<div class="chatlog__attachment${u?` chatlog__attachment--hidden`:``}" ${u?`onclick="showSpoiler(event, this)"`:``}>${u?`<div class="chatlog__attachment-spoiler-caption">SPOILER</div>`:``}<img class="chatlog__attachment-media" src="${r}" alt="${t}" loading="lazy" onclick="openLightbox('${r}')" /><div class="chatlog__attachment-info">${t} ${i?`(${i})`:``}</div></div>`:c?`<div class="chatlog__attachment"><video class="chatlog__attachment-media" controls preload="metadata" src="${r}"></video><div class="chatlog__attachment-info">${t} ${i?`(${i})`:``}</div></div>`:l?`<div class="chatlog__attachment"><audio class="chatlog__attachment-audio" controls preload="metadata" src="${r}"></audio><div class="chatlog__attachment-info">${t} ${i?`(${i})`:``}</div></div>`:`<div class="chatlog__attachment-generic"><svg class="chatlog__attachment-generic-icon" viewBox="0 0 24 24"><path fill="currentColor" d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg><div class="chatlog__attachment-generic-details"><a class="chatlog__attachment-generic-name" href="${r}" target="_blank" rel="noopener noreferrer">${t}</a>${i?`<span class="chatlog__attachment-generic-size">${i}</span>`:``}</div></div>`}function c(e,t,r){var a=e.color?`#${e.color.toString(16).padStart(6,`0`)}`:`#202225`,o=e.author?.name?`<div class="chatlog__embed-author-container">${e.author.icon_url?`<img class="chatlog__embed-author-icon" src="${n(e.author.icon_url)}" alt="" loading="lazy" />`:``}<span class="chatlog__embed-author">${n(e.author.name)}</span></div>`:``,s=e.title?e.url?`<div class="chatlog__embed-title"><a href="${n(e.url)}" target="_blank" rel="noopener noreferrer">${n(e.title)}</a></div>`:`<div class="chatlog__embed-title">${n(e.title)}</div>`:``,c=e.description?`<div class="chatlog__embed-description">${i(e.description,t,r)}</div>`:``,l=``;e.fields&&e.fields.length>0&&(l=`<div class="chatlog__embed-fields">${e.fields.map(function(e){return`<div class="chatlog__embed-field ${e.inline?`chatlog__embed-field--inline`:``}"><div class="chatlog__embed-field-name">${n(e.name)}</div><div class="chatlog__embed-field-value">${i(e.value,t,r)}</div></div>`}).join(``)}</div>`);var u=e.thumbnail?.url?`<img class="chatlog__embed-thumbnail" src="${n(e.thumbnail.url)}" alt="Thumbnail" loading="lazy" />`:``,d=e.image?.url?`<div class="chatlog__embed-images chatlog__embed-images--single"><img class="chatlog__embed-image" src="${n(e.image.url)}" alt="Image" loading="lazy" onclick="openLightbox('${n(e.image.url)}')" /></div>`:``,f=``;if(e.footer?.text||e.timestamp){var p=e.footer?.icon_url?`<img class="chatlog__embed-footer-icon" src="${n(e.footer.icon_url)}" alt="" loading="lazy" />`:``,m=e.footer?.text?n(e.footer.text):``,h=e.timestamp?new Date(e.timestamp).toLocaleString():``;f=`<div class="chatlog__embed-footer">${p}<span class="chatlog__embed-footer-text">${m}${m&&h?` • `:``}${h}</span></div>`}return`<div class="chatlog__embed"><div class="chatlog__embed-color-pill" style="background-color: ${a};"></div><div class="chatlog__embed-content-container"><div class="chatlog__embed-content"><div class="chatlog__embed-text">${o}${s}${c}${l}${d}${f}</div>${u}</div></div></div>`}function l(e,t,r){var o=n(e.name),l=e.guildName?n(e.guildName):`Direct Message`,u=e.topic?n(e.topic):``,d=(/* @__PURE__ */ new Date()).toLocaleString(),f=/* @__PURE__ */ new Map,p=/* @__PURE__ */ new Map,m=/* @__PURE__ */ new Map;e.id&&p.set(e.id,e.name);for(var h of t)h.id&&m.set(h.id,h),h.author?.id&&f.set(h.author.id,h.nick||h.author.globalName||h.author.username||`User`);for(var g=``,_=[],v=``,y=0,b=function(){if(_.length!==0){for(var e=``,t=0;t<_.length;t++){var o=_[t],l=t===0,u=o.author??{id:`0`,username:`Unknown`},d=n(o.nick||u.globalName||u.username||`Unknown`),h=n(u.username||``),v=(u.globalName||o.nick)&&u.globalName!==u.username&&o.nick!==u.username,y=o.colorString?`color: ${o.colorString};`:``,b=o.timestamp?new Date(o.timestamp).getTime():0,x=b?new Date(b).toLocaleString():``,S=b?new Date(b).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`}):``,C=i(o.content??``,f,p),w=``;r.includeAttachments&&o.attachments&&o.attachments.length>0&&(w=`<div class="chatlog__attachments">${o.attachments.map(s).join(``)}</div>`);var T=``;r.includeEmbeds&&o.embeds&&o.embeds.length>0&&(T=`<div class="chatlog__embeds">${o.embeds.map(function(e){return c(e,f,p)}).join(``)}</div>`);var E=``;o.reactions&&o.reactions.length>0&&(E=`<div class="chatlog__reactions">${o.reactions.map(function(e){var t=e.emoji,r=e.count;if(t.id){var i=t.animated?`gif`:`webp`,a=`https://cdn.discordapp.com/emojis/${t.id}.${i}?size=48&quality=lossless`;return`<div class="chatlog__reaction" title="${n(t.name)}"><img class="chatlog__emoji chatlog__emoji--small" alt="${n(t.name)}" src="${a}" loading="lazy" /><span class="chatlog__reaction-count">${r}</span></div>`}return`<div class="chatlog__reaction" title="${n(t.name)}"><span class="chatlog__reaction-emoji">${n(t.name)}</span><span class="chatlog__reaction-count">${r}</span></div>`}).join(``)}</div>`);var D=``;o.stickerItems&&o.stickerItems.length>0&&(D=`<div class="chatlog__stickers">${o.stickerItems.map(function(e){return`<div class="chatlog__sticker" title="${n(e.name)}"><img class="chatlog__sticker--media" src="https://media.discordapp.net/stickers/${e.id}.png?size=160" alt="${n(e.name)}" loading="lazy" /></div>`}).join(``)}</div>`);var O=``,k=o.referencedMessage?.id??o.messageReference?.message_id;if(k){var A=o.referencedMessage??m.get(k);if(A){var j=n(A.nick||A.author?.globalName||A.author?.username||`User`),M=A.colorString?`color: ${A.colorString};`:``;O=`<div class="chatlog__reply"><div class="chatlog__reply-symbol"></div><img class="chatlog__reply-avatar" src="${a(A.author,0)}" alt="" loading="lazy" /><span class="chatlog__reply-author" style="${M}">${j}</span><a class="chatlog__reply-content chatlog__reply-link" onclick="scrollToMessage(event, '${k}')">${A.content?n(A.content.length>70?`${A.content.slice(0,70)}...`:A.content):A.attachments?.length?`Click to see attachment`:`Message`}</a></div>`}else O=`<div class="chatlog__reply"><div class="chatlog__reply-symbol"></div><a class="chatlog__reply-content chatlog__reply-link" onclick="scrollToMessage(event, '${k}')">Original message was deleted or not loaded.</a></div>`}if(l){var N=a(u,0),P=u.bot?`<span class="chatlog__author-tag">BOT</span>`:``,F=u.system?`<span class="chatlog__author-tag system">SYSTEM</span>`:``;e+=`<div id="chatlog__message-container-${o.id}" class="chatlog__message-container ${o.pinned?`chatlog__message-container--pinned`:``}" data-message-id="${o.id}"><div class="chatlog__message"><div class="chatlog__message-aside"><img class="chatlog__avatar" src="${N}" alt="${d}" loading="lazy" onerror="this.src='https://cdn.discordapp.com/embed/avatars/0.png'"/></div><div class="chatlog__message-primary">${O}<div class="chatlog__header"><span class="chatlog__author" style="${y}">${d}</span>${v?`<span class="chatlog__author-handle">@${h}</span>`:``}${P}${F}${r.includeTimestamps&&x?`<span class="chatlog__timestamp" title="${x}">${x}</span>`:``}</div><div class="chatlog__content">${C}</div>${w}${T}${D}${E}</div></div></div>`}else e+=`<div id="chatlog__message-container-${o.id}" class="chatlog__message-container ${o.pinned?`chatlog__message-container--pinned`:``}" data-message-id="${o.id}"><div class="chatlog__message chatlog__message--coalesced"><div class="chatlog__message-aside"><span class="chatlog__short-timestamp" title="${x}">${S}</span></div><div class="chatlog__message-primary">${O}<div class="chatlog__content">${C}</div>${w}${T}${D}${E}</div></div></div>`}g+=`<div class="chatlog__message-group">${e}</div>`,_=[]}},x=0;x<t.length;x++){var S=t[x],C=S.author?.id??`0`,w=S.timestamp?new Date(S.timestamp).getTime():0;!(S.referencedMessage||S.messageReference?.message_id)&&_.length>0&&v===C&&w>0&&y>0&&w-y<3e5?(_.push(S),y=w):(b(),_.push(S),v=C,y=w)}return b(),`<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>${l} - #${o}</title>
	<style>
		:root {
			--bg-primary: #313338;
			--bg-secondary: #2b2d31;
			--bg-tertiary: #1e1f22;
			--bg-hover: #2e3035;
			--text-normal: #dbdee1;
			--text-muted: #949ba4;
			--text-header: #f2f3f5;
			--brand-color: #5865f2;
			--brand-hover: #4752c4;
			--border-subtle: #3f4147;
			--mention-bg: rgba(88, 101, 242, 0.3);
			--mention-text: #dee0fc;
			--font-main: "gg sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
			--font-code: Consolas, "Andale Mono WT", "Andale Mono", "Lucida Console", "Courier New", Courier, monospace;
		}

		* {
			box-sizing: border-box;
			margin: 0;
			padding: 0;
		}

		html, body {
			background-color: var(--bg-primary);
			color: var(--text-normal);
			font-family: var(--font-main);
			font-size: 16px;
			line-height: 1.375;
			scroll-behavior: smooth;
		}

		a {
			color: #00a8fc;
			text-decoration: none;
		}

		a:hover {
			text-decoration: underline;
		}

				header {
			position: sticky;
			top: 0;
			z-index: 100;
			background-color: var(--bg-secondary);
			border-bottom: 1px solid var(--border-subtle);
			padding: 8px 16px;
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 12px;
			box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25);
			height: 48px;
		}

		.header-left {
			display: flex;
			align-items: center;
			gap: 8px;
			min-width: 0;
			flex: 1;
		}

		.channel-hash {
			color: var(--text-muted);
			font-size: 20px;
			font-weight: 600;
			flex-shrink: 0;
		}

		.channel-title-wrap {
			display: flex;
			align-items: baseline;
			gap: 8px;
			overflow: hidden;
			white-space: nowrap;
		}

		.channel-name {
			color: var(--text-header);
			font-size: 16px;
			font-weight: 700;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		.guild-name {
			color: var(--text-muted);
			font-size: 12px;
			font-weight: 500;
			flex-shrink: 0;
		}

		.topic-toggle-btn {
			background: transparent;
			border: 1px solid var(--border-subtle);
			color: var(--text-muted);
			font-size: 11px;
			font-weight: 600;
			padding: 2px 8px;
			border-radius: 4px;
			cursor: pointer;
			flex-shrink: 0;
			transition: background-color 0.15s, color 0.15s;
		}

		.topic-toggle-btn:hover {
			color: var(--text-normal);
			background-color: var(--bg-tertiary);
		}

		.header-right {
			display: flex;
			align-items: center;
			gap: 10px;
			flex-shrink: 0;
		}

		.search-box {
			display: flex;
			align-items: center;
			background-color: var(--bg-tertiary);
			border-radius: 4px;
			padding: 4px 8px;
			border: 1px solid transparent;
			transition: border-color 0.2s;
		}

		.search-box:focus-within {
			border-color: var(--brand-color);
		}

		.search-box input {
			background: transparent;
			border: none;
			outline: none;
			color: var(--text-normal);
			font-size: 13px;
			font-family: inherit;
			width: 130px;
		}

		.search-box input::placeholder {
			color: var(--text-muted);
		}

		.stats-badge {
			background-color: var(--bg-tertiary);
			color: var(--text-muted);
			font-size: 11px;
			padding: 4px 8px;
			border-radius: 4px;
			white-space: nowrap;
		}

				.topic-panel {
			position: sticky;
			top: 48px;
			z-index: 90;
			background-color: rgba(30, 31, 34, 0.95);
			backdrop-filter: blur(8px);
			border-bottom: 1px solid var(--border-subtle);
			padding: 10px 16px;
			font-size: 13px;
			color: var(--text-muted);
			transition: max-height 0.2s ease, opacity 0.2s ease;
			overflow: hidden;
		}

		.topic-panel.collapsed {
			display: none;
		}

				.preamble {
			display: grid;
			grid-template-columns: auto 1fr;
			max-width: 1200px;
			margin: 0 auto;
			padding: 24px 16px 16px 16px;
			gap: 16px;
		}

		.preamble__guild-icon-container {
			grid-column: 1;
		}

		.preamble__guild-icon {
			width: 72px;
			height: 72px;
			border-radius: 18px;
			object-fit: cover;
		}

		.preamble__guild-icon-placeholder {
			width: 72px;
			height: 72px;
			border-radius: 18px;
			background-color: var(--brand-color);
			color: #fff;
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 32px;
			font-weight: 700;
		}

		.preamble__entries-container {
			grid-column: 2;
			display: flex;
			flex-direction: column;
			justify-content: center;
			gap: 4px;
		}

		.preamble__entry {
			color: var(--text-header);
			font-size: 1.3rem;
			font-weight: 700;
		}

		.preamble__channel-title {
			font-size: 1.1rem;
			color: var(--text-normal);
		}

		.preamble__entry--small {
			font-size: 0.875rem;
			font-weight: 400;
			color: var(--text-muted);
		}

				.chatlog {
			padding: 8px 0 40px 0;
			width: 100%;
			max-width: 1200px;
			margin: 0 auto;
		}

		.chatlog__message-group {
			margin-bottom: 12px;
		}

		.chatlog__message-container {
			background-color: transparent;
			transition: background-color 0.8s ease;
		}

		.chatlog__message-container--highlighted {
			background-color: rgba(114, 137, 218, 0.25) !important;
		}

		.chatlog__message-container--pinned {
			background-color: rgba(249, 168, 37, 0.05);
		}

		.chatlog__message {
			display: grid;
			grid-template-columns: 72px 1fr;
			padding: 2px 16px;
			min-height: 28px;
			transition: background-color 0.1s;
		}

		.chatlog__message:hover {
			background-color: var(--bg-hover);
		}

		.chatlog__message-aside {
			grid-column: 1;
			width: 72px;
			text-align: center;
			padding-top: 2px;
			flex-shrink: 0;
		}

		.chatlog__avatar {
			width: 40px;
			height: 40px;
			border-radius: 50%;
			object-fit: cover;
		}

		.chatlog__short-timestamp {
			display: none;
			color: var(--text-muted);
			font-size: 0.6875rem;
			font-weight: 500;
			line-height: 22px;
			user-select: none;
		}

		.chatlog__message:hover .chatlog__short-timestamp {
			display: block;
		}

		.chatlog__message-primary {
			grid-column: 2;
			min-width: 0;
			padding-right: 12px;
		}

				.chatlog__reply {
			display: flex;
			align-items: center;
			margin-bottom: 4px;
			font-size: 0.8125rem;
			color: #b5b6b8;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		.chatlog__reply-symbol {
			width: 12px;
			height: 8px;
			margin-right: 6px;
			margin-left: 20px;
			border-left: 2px solid #4f545c;
			border-top: 2px solid #4f545c;
			border-top-left-radius: 6px;
			flex-shrink: 0;
		}

		.chatlog__reply-avatar {
			width: 16px;
			height: 16px;
			margin-right: 6px;
			border-radius: 50%;
			flex-shrink: 0;
		}

		.chatlog__reply-author {
			margin-right: 6px;
			font-weight: 600;
			color: #fff;
			flex-shrink: 0;
		}

		.chatlog__reply-link {
			color: #b5b6b8;
			cursor: pointer;
			overflow: hidden;
			text-overflow: ellipsis;
			text-decoration: none;
		}

		.chatlog__reply-link:hover {
			color: #fff;
			text-decoration: underline;
		}

				.chatlog__header {
			display: flex;
			align-items: baseline;
			gap: 6px;
			margin-bottom: 2px;
		}

		.chatlog__author {
			font-weight: 600;
			color: #ffffff;
			font-size: 1rem;
		}

		.chatlog__author-handle {
			font-size: 0.75rem;
			color: var(--text-muted);
		}

		.chatlog__author-tag {
			font-size: 0.625rem;
			font-weight: 700;
			background-color: var(--brand-color);
			color: #ffffff;
			padding: 1px 4px;
			border-radius: 3px;
			line-height: 1.2;
		}

		.chatlog__author-tag.system {
			background-color: #eb459e;
		}

		.chatlog__timestamp {
			color: var(--text-muted);
			font-size: 0.75rem;
			font-weight: 500;
			margin-left: 4px;
		}

				.chatlog__content {
			font-size: 0.95rem;
			color: var(--text-normal);
			word-wrap: break-word;
			line-height: 1.375;
		}

		.chatlog__content:empty {
			display: none;
		}

		.chatlog__content h1 { font-size: 1.4rem; font-weight: 700; margin: 8px 0 4px 0; color: var(--text-header); }
		.chatlog__content h2 { font-size: 1.2rem; font-weight: 700; margin: 6px 0 3px 0; color: var(--text-header); }
		.chatlog__content h3 { font-size: 1.05rem; font-weight: 600; margin: 4px 0 2px 0; color: var(--text-header); }
		.chatlog__markdown-subtext { font-size: 0.75rem; color: var(--text-muted); margin-top: 2px; }

		.chatlog__markdown-quote {
			display: flex;
			margin: 4px 0;
		}

		.chatlog__markdown-quote-border {
			margin-right: 8px;
			border-left: 4px solid #4f545c;
			border-radius: 2px;
		}

		.chatlog__markdown-quote-content {
			color: var(--text-normal);
		}

		.chatlog__markdown-pre {
			background-color: var(--bg-secondary);
			font-family: var(--font-code);
			font-size: 0.85rem;
		}

		.chatlog__markdown-pre--multiline {
			display: block;
			margin: 6px 0;
			padding: 10px 12px;
			border: 1px solid var(--border-subtle);
			border-radius: 4px;
			color: #b9bbbe;
			white-space: pre-wrap;
			overflow-x: auto;
		}

		.chatlog__markdown-pre--inline {
			display: inline-block;
			padding: 2px 4px;
			border-radius: 3px;
		}

		.chatlog__markdown-mention {
			border-radius: 3px;
			padding: 0 4px;
			background-color: var(--mention-bg);
			color: var(--mention-text);
			font-weight: 500;
		}

		.chatlog__markdown-mention:hover {
			background-color: var(--brand-color);
			color: #ffffff;
		}

		.chatlog__markdown-timestamp {
			background-color: rgba(255, 255, 255, 0.08);
			padding: 1px 4px;
			border-radius: 3px;
			font-size: 0.85rem;
		}

		.chatlog__emoji {
			width: 1.375rem;
			height: 1.375rem;
			vertical-align: -0.35rem;
			object-fit: contain;
			margin: 0 1px;
		}

		.chatlog__emoji--small {
			width: 1rem;
			height: 1rem;
		}

		.chatlog__emoji--large {
			width: 2.75rem;
			height: 2.75rem;
		}

				.chatlog__markdown-spoiler {
			background-color: rgba(255, 255, 255, 0.1);
			padding: 0 3px;
			border-radius: 3px;
		}

		.chatlog__markdown-spoiler--hidden {
			cursor: pointer;
			background-color: #202225;
			color: transparent;
			user-select: none;
		}

		.chatlog__markdown-spoiler--hidden:hover {
			background-color: rgba(32, 34, 37, 0.8);
		}

				.chatlog__attachments {
			margin-top: 6px;
			display: flex;
			flex-direction: column;
			gap: 8px;
		}

		.chatlog__attachment {
			position: relative;
			width: fit-content;
			border-radius: 4px;
			overflow: hidden;
		}

		.chatlog__attachment-media {
			max-width: 45vw;
			max-height: 450px;
			border-radius: 4px;
			display: block;
			object-fit: contain;
			cursor: pointer;
			transition: opacity 0.2s;
		}

		.chatlog__attachment-media:hover {
			opacity: 0.95;
		}

		.chatlog__attachment-audio {
			width: 100%;
			max-width: 400px;
		}

		.chatlog__attachment-info {
			font-size: 0.75rem;
			color: var(--text-muted);
			margin-top: 4px;
		}

		.chatlog__attachment--hidden {
			cursor: pointer;
		}

		.chatlog__attachment--hidden .chatlog__attachment-media {
			filter: blur(44px);
		}

		.chatlog__attachment-spoiler-caption {
			display: none;
			position: absolute;
			left: 50%;
			top: 50%;
			z-index: 10;
			padding: 6px 14px;
			border-radius: 20px;
			transform: translate(-50%, -50%);
			background-color: rgba(0, 0, 0, 0.85);
			color: #dcddde;
			font-size: 13px;
			font-weight: 700;
			letter-spacing: 0.5px;
		}

		.chatlog__attachment--hidden .chatlog__attachment-spoiler-caption {
			display: block;
		}

		.chatlog__attachment-generic {
			display: inline-flex;
			align-items: center;
			gap: 12px;
			background-color: var(--bg-secondary);
			border: 1px solid var(--border-subtle);
			border-radius: 6px;
			padding: 10px 14px;
			max-width: 420px;
		}

		.chatlog__attachment-generic-icon {
			color: var(--text-muted);
			width: 24px;
			height: 24px;
			flex-shrink: 0;
		}

		.chatlog__attachment-generic-details {
			display: flex;
			flex-direction: column;
			overflow: hidden;
		}

		.chatlog__attachment-generic-name {
			color: #00a8fc;
			font-size: 14px;
			font-weight: 600;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		.chatlog__attachment-generic-size {
			font-size: 11px;
			color: var(--text-muted);
		}

				.chatlog__embeds {
			margin-top: 6px;
			display: flex;
			flex-direction: column;
			gap: 8px;
		}

		.chatlog__embed {
			display: flex;
			margin-top: 4px;
			max-width: 520px;
		}

		.chatlog__embed-color-pill {
			flex-shrink: 0;
			width: 4px;
			border-top-left-radius: 4px;
			border-bottom-left-radius: 4px;
		}

		.chatlog__embed-content-container {
			display: flex;
			flex-direction: column;
			padding: 10px 14px;
			border: 1px solid var(--border-subtle);
			border-top-right-radius: 4px;
			border-bottom-right-radius: 4px;
			background-color: var(--bg-secondary);
			width: 100%;
		}

		.chatlog__embed-content {
			display: flex;
			width: 100%;
		}

		.chatlog__embed-text {
			flex: 1;
		}

		.chatlog__embed-author-container {
			display: flex;
			align-items: center;
			gap: 6px;
			margin-bottom: 4px;
		}

		.chatlog__embed-author-icon {
			width: 18px;
			height: 18px;
			border-radius: 50%;
		}

		.chatlog__embed-author {
			color: var(--text-header);
			font-size: 0.8125rem;
			font-weight: 600;
		}

		.chatlog__embed-title {
			color: var(--text-header);
			font-size: 0.9375rem;
			font-weight: 700;
			margin-bottom: 4px;
		}

		.chatlog__embed-description {
			font-size: 0.875rem;
			color: var(--text-normal);
			margin-bottom: 6px;
			word-wrap: break-word;
		}

		.chatlog__embed-fields {
			display: grid;
			grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
			gap: 8px;
			margin-top: 6px;
		}

		.chatlog__embed-field-name {
			font-size: 0.75rem;
			font-weight: 700;
			color: var(--text-header);
		}

		.chatlog__embed-field-value {
			font-size: 0.8125rem;
			color: var(--text-normal);
		}

		.chatlog__embed-thumbnail {
			max-width: 80px;
			max-height: 80px;
			margin-left: 12px;
			border-radius: 4px;
			object-fit: cover;
		}

		.chatlog__embed-image {
			max-width: 100%;
			max-height: 350px;
			border-radius: 4px;
			margin-top: 6px;
			cursor: pointer;
		}

		.chatlog__embed-footer {
			margin-top: 8px;
			display: flex;
			align-items: center;
			gap: 6px;
			color: var(--text-muted);
			font-size: 0.6875rem;
		}

		.chatlog__embed-footer-icon {
			width: 16px;
			height: 16px;
			border-radius: 50%;
		}

				.chatlog__reactions {
			display: flex;
			flex-wrap: wrap;
			gap: 4px;
			margin-top: 6px;
		}

		.chatlog__reaction {
			display: inline-flex;
			align-items: center;
			gap: 4px;
			padding: 2px 6px;
			border: 1px solid transparent;
			border-radius: 8px;
			background-color: var(--bg-secondary);
			cursor: default;
			transition: border-color 0.15s;
		}

		.chatlog__reaction:hover {
			border-color: rgba(255, 255, 255, 0.2);
		}

		.chatlog__reaction-count {
			color: var(--text-muted);
			font-size: 0.75rem;
			font-weight: 600;
		}

				.chatlog__stickers {
			margin-top: 6px;
		}

		.chatlog__sticker {
			width: 160px;
			height: 160px;
		}

		.chatlog__sticker--media {
			max-width: 100%;
			max-height: 100%;
			object-fit: contain;
		}

				.postamble {
			padding: 24px 16px;
			max-width: 1200px;
			margin: 0 auto;
			border-top: 1px solid var(--border-subtle);
			color: var(--text-muted);
			font-size: 0.8125rem;
			display: flex;
			flex-direction: column;
			gap: 4px;
		}

		.postamble__entry:first-child {
			color: var(--text-header);
			font-weight: 600;
		}

				.lightbox-modal {
			display: none;
			position: fixed;
			top: 0;
			left: 0;
			width: 100vw;
			height: 100vh;
			background-color: rgba(0, 0, 0, 0.88);
			backdrop-filter: blur(6px);
			z-index: 9999;
			align-items: center;
			justify-content: center;
			cursor: zoom-out;
			padding: 16px;
		}

		.lightbox-modal.active {
			display: flex;
		}

		.lightbox-box {
			display: flex;
			align-items: center;
			justify-content: center;
			max-width: 95vw;
			max-height: 95vh;
			cursor: default;
		}

		.lightbox-img {
			max-width: 90vw;
			max-height: 85vh;
			object-fit: contain;
			border-radius: 6px;
			box-shadow: 0 8px 32px rgba(0, 0, 0, 0.8);
		}

				.floating-actions {
			position: fixed;
			bottom: 24px;
			right: 24px;
			display: flex;
			flex-direction: column;
			gap: 10px;
			z-index: 999;
		}

		.floating-btn {
			width: 40px;
			height: 40px;
			border-radius: 50%;
			background-color: var(--brand-color);
			color: #fff;
			border: none;
			cursor: pointer;
			display: flex;
			align-items: center;
			justify-content: center;
			box-shadow: 0 4px 10px rgba(0, 0, 0, 0.4);
			transition: background-color 0.2s, transform 0.1s;
		}

		.floating-btn:hover {
			background-color: var(--brand-hover);
			transform: scale(1.05);
		}

		.floating-btn svg {
			fill: currentColor;
			width: 18px;
			height: 18px;
		}

		@media (max-width: 768px) {
			header {
				padding: 6px 12px;
			}
			.search-box input {
				width: 90px;
			}
			.chatlog__message {
				grid-template-columns: 52px 1fr;
				padding: 2px 8px;
			}
			.chatlog__message-aside {
				width: 52px;
			}
			.chatlog__avatar {
				width: 34px;
				height: 34px;
			}
			.chatlog__attachment-media {
				max-width: 75vw;
			}
		}
	</style>
</head>
<body>
	<header>
		<div class="header-left">
			<span class="channel-hash">#</span>
			<div class="channel-title-wrap">
				<span class="channel-name">${o}</span>
				<span class="guild-name">${l}</span>
			</div>
			${u?`<button class="topic-toggle-btn" onclick="toggleTopic()">Topic</button>`:``}
		</div>
		<div class="header-right">
			<div class="search-box">
				<input type="text" id="searchInput" placeholder="Search..." />
			</div>
			<div class="stats-badge" id="statsBadge" title="Exported ${d}">
				${t.length} msgs
			</div>
		</div>
	</header>

	${u?`<div id="topicPanel" class="topic-panel collapsed">${u}</div>`:``}

	<div class="preamble">
		<div class="preamble__guild-icon-container">
			${e.guildIconUrl?`<img class="preamble__guild-icon" src="${n(e.guildIconUrl)}" alt="Guild icon" loading="lazy" />`:`<div class="preamble__guild-icon-placeholder">#</div>`}
		</div>
		<div class="preamble__entries-container">
			<div class="preamble__entry">${l}</div>
			<div class="preamble__channel-title">#${o}</div>
			${u?`<div class="preamble__entry preamble__entry--small">${u}</div>`:``}
			<div class="preamble__entry preamble__entry--small">${n(e.rangeDescription||`Exported ${t.length} message(s)`)} • ${d}</div>
		</div>
	</div>

	<main class="chatlog" id="chatStream">
		${g||`<div style="text-align:center; padding:40px; color:var(--text-muted);">No messages found.</div>`}
	</main>

	<div class="postamble">
		<div class="postamble__entry">Exported ${t.length} message(s)</div>
		<div class="postamble__entry">${l} • #${o} • ${d}</div>
	</div>

	<div id="lightbox" class="lightbox-modal" onclick="closeLightbox(event)">
		<div class="lightbox-box">
			<img id="lightboxImg" class="lightbox-img" src="" alt="Preview" />
		</div>
	</div>

	<div class="floating-actions">
		<button class="floating-btn" title="Jump to top" onclick="window.scrollTo({ top: 0, behavior: 'smooth' })">
			<svg viewBox="0 0 24 24"><path d="M7.41 15.41L12 10.83l4.59 4.58L18 14l-6-6-6 6z"/></svg>
		</button>
		<button class="floating-btn" title="Jump to bottom" onclick="window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })">
			<svg viewBox="0 0 24 24"><path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z"/></svg>
		</button>
	</div>

	<script>
		function openLightbox(url) {
			const lb = document.getElementById('lightbox');
			const img = document.getElementById('lightboxImg');
			img.src = url;
			lb.classList.add('active');
		}

		function closeLightbox(e) {
			if (!e || e.target !== document.getElementById('lightboxImg')) {
				const lb = document.getElementById('lightbox');
				lb.classList.remove('active');
				document.getElementById('lightboxImg').src = '';
			}
		}

		document.addEventListener('keydown', function(e) {
			if (e.key === 'Escape') {
				closeLightbox();
			}
		});

		function showSpoiler(event, element) {
			if (!element) return;
			if (element.classList.contains('chatlog__attachment--hidden')) {
				event.preventDefault();
				element.classList.remove('chatlog__attachment--hidden');
			}
			if (element.classList.contains('chatlog__markdown-spoiler--hidden')) {
				event.preventDefault();
				element.classList.remove('chatlog__markdown-spoiler--hidden');
			}
		}

		function scrollToMessage(event, id) {
			const element = document.getElementById('chatlog__message-container-' + id);
			if (!element) return;
			event.preventDefault();
			element.classList.add('chatlog__message-container--highlighted');
			window.scrollTo({
				top: element.getBoundingClientRect().top + window.pageYOffset - (window.innerHeight / 2),
				behavior: 'smooth'
			});
			setTimeout(function() {
				element.classList.remove('chatlog__message-container--highlighted');
			}, 2000);
		}

		function toggleTopic() {
			const panel = document.getElementById('topicPanel');
			if (panel) {
				panel.classList.toggle('collapsed');
			}
		}

		const searchInput = document.getElementById('searchInput');
		const statsBadge = document.getElementById('statsBadge');
		const containers = document.querySelectorAll('.chatlog__message-container');
		const totalCount = containers.length;

		if (searchInput) {
			searchInput.addEventListener('input', function() {
				const query = searchInput.value.toLowerCase().trim();
				let visible = 0;
				containers.forEach(function(c) {
					const text = c.innerText.toLowerCase();
					const match = !query || text.includes(query);
					c.style.display = match ? '' : 'none';
					if (match) visible++;
				});
				statsBadge.innerText = query ? visible + ' / ' + totalCount + ' msgs' : totalCount + ' msgs';
			});
		}
	<\/script>
</body>
</html>`}function u(e){return e?e.discriminator&&e.discriminator!==`0`?`${e.username}#${e.discriminator}`:e.globalName?`${e.globalName} (@${e.username})`:e.username:`Unknown Author`}function d(e,t){var n=[],r=``;if(t.includeTimestamps&&e.timestamp){var i=new Date(e.timestamp);Number.isNaN(i.getTime())||(r+=`[${i.toLocaleString()}] `)}if(r+=`${u(e.author)}:`,n.push(`${r} ${e.content??``}`),t.includeAttachments&&e.attachments&&e.attachments.length>0){n.push(`  Attachments:`);for(var a of e.attachments){var o=a.size?` (${(a.size/1024).toFixed(1)} KB)`:``;n.push(`    - ${a.filename}${o}: ${a.url}`)}}if(t.includeEmbeds&&e.embeds&&e.embeds.length>0){n.push(`  Embeds:`);for(var s of e.embeds)if(s.title&&n.push(`    - Title: ${s.title}`),s.url&&n.push(`      URL: ${s.url}`),s.description&&n.push(`      Description: ${s.description}`),s.fields&&s.fields.length>0)for(var c of s.fields)n.push(`      • ${c.name}: ${c.value}`)}return n.join(`
`)}function f(e,t,n){var r=[`# Chat Export: ${n.name}`,n.guildName?`Server: ${n.guildName}`:``,n.topic?`Topic: ${n.topic}`:``,`Exported At: ${n.exportedAt}`,`Total Messages: ${e.length}`,`=`.repeat(50),``].filter(Boolean);for(var i of e)r.push(d(i,t)),r.push(``);return r.join(`
`)}function p(e,t){var n={id:e.id,channel_id:e.channel_id,author:{id:e.author.id,username:e.author.username,discriminator:e.author.discriminator,globalName:e.author.globalName,bot:e.author.bot,avatar:e.author.avatar},content:e.content??``};return t.includeTimestamps&&e.timestamp&&(n.timestamp=e.timestamp),t.includeAttachments&&e.attachments&&(n.attachments=e.attachments.map(function(e){return{filename:e.filename,url:e.url,size:e.size,contentType:e.content_type}})),t.includeEmbeds&&e.embeds&&(n.embeds=e.embeds.map(function(e){return{title:e.title,description:e.description,url:e.url,fields:e.fields}})),JSON.stringify(n,null,2)}function m(e,t,n){var r={meta:n,messages:e.map(function(e){return JSON.parse(p(e,t))})};return JSON.stringify(r,null,2)}function h(e,t){return t.format===`html`?l({id:e.channel_id??`0`,name:`Message Export`,totalMessages:1,exportedAt:(/* @__PURE__ */ new Date()).toISOString()},[e],t):t.format===`json`?p(e,t):d(e,t)}function g(e,t,n){return t.format===`html`?l(n,e,t):t.format===`json`?m(e,t,n):f(e,t,n)}function _(e,t=`success`){try{if(typeof valenced.discord.actions.ToastActionCreators?.open==`function`){if(valenced.discord.actions.ToastActionCreators.open.length===1){var n=valenced.discord.actions.ToastActionCreators.open;n({key:`hieuxyz-export-messages`,text:e,variant:t})}else valenced.discord.actions.ToastActionCreators.open(`hieuxyz-export-messages`,{text:e,variant:t})}}catch{}}function v(){try{var e=globalThis.valenced;return typeof e?.hieuxyz?.saf?.isSafAvailable==`function`&&e.hieuxyz.saf.isSafAvailable()}catch{return!1}}function y(e){return e.endsWith(`.html`)?`text/html`:e.endsWith(`.json`)?`application/json`:`text/plain`}async function b(e,t,n){if(t===`clipboard`)valenced.externals.ReactNativeClipboard.Clipboard.setString(e),_(`Copied to clipboard!`,`success`);else{if(t===`saf`&&v())try{var r=y(n);if(await globalThis.valenced?.hieuxyz?.saf?.saveViaSaf?.(n,r,e)){_(`Save file dialog opened.`,`success`);return}}catch{}if(valenced.react.ReactNative.Platform.OS===`ios`)try{var i=globalThis.valenced?.modules?.native,a=i?.callNativeMethodSync?.(`valenced.fs.getConstants`,[]);if(a?.cache&&i?.callNativeMethod){var o=`${a.cache}/${n}`;if(await i.callNativeMethod(`valenced.fs.write`,[o,e]),valenced.react.ReactNative?.Share?.share){await valenced.react.ReactNative.Share.share({url:`file://${o}`,title:n}),_(`Shared successfully!`,`success`);return}}}catch{}try{valenced.react.ReactNative?.Share?.share?(await valenced.react.ReactNative.Share.share({message:e,title:n}),_(`Shared successfully!`,`success`)):(valenced.externals.ReactNativeClipboard.Clipboard.setString(e),_(`Share unavailable, copied to clipboard instead.`,`default`))}catch{valenced.externals.ReactNativeClipboard.Clipboard.setString(e),_(`Export failed, copied to clipboard instead.`,`critical`)}}}async function x(e,t,n,r){var i;if(t.format===`html`){var a=e.channel_id,{channelName:o,guildName:s,guildIconUrl:c,topic:l}=C(a),u={id:a??`0`,name:o,guildName:s,guildIconUrl:c,topic:l,totalMessages:1,exportedAt:(/* @__PURE__ */ new Date()).toISOString(),rangeDescription:`Single Message ID ${e.id}`};i=g([e],t,u)}else i=h(e,t);var d=t.format===`html`?`html`:t.format===`json`?`json`:`txt`,f=r?.trim()||`discord_msg_${e.id}.${d}`;await b(i,n,f)}async function S(e,t,n=`before`){var r=valenced.discord.flux.Stores.MessageStore,i=r?.getMessages?.(e),a=i?.toArray?.()??i?._array??[];if(a.length>=t)return a;var o=globalThis.valenced?.modules?.finders,s=o?.lookupModule?.(o.filters.withProps(`sendMessage`))?.[0];if(!s?.fetchMessages)return a;var c=0,l=20;for(_(`Loading messages (${a.length}/${t})...`,`default`);a.length<t&&(n===`before`&&i?.hasMoreBefore||n===`after`&&i?.hasMoreAfter)&&c<l;){c++;var u=Math.min(50,t-a.length);if(n===`before`){var d=a[0];if(!d?.id)break;s.fetchMessages({channelId:e,before:d.id,limit:u})}else{var f=a[a.length-1];if(!f?.id)break;s.fetchMessages({channelId:e,after:f.id,limit:u})}await new Promise(function(e){return setTimeout(e,650)}),i=r?.getMessages?.(e);var p=i?.toArray?.()??i?._array??[];if(p.length===a.length){await new Promise(function(e){return setTimeout(e,650)}),i=r?.getMessages?.(e);var m=i?.toArray?.()??i?._array??[];if(m.length===a.length)break;a=m}else a=p}return a}function C(e){var t=valenced.discord.flux.Stores.SelectedChannelStore,n=valenced.discord.flux.Stores.ChannelStore,r=valenced.discord.flux.Stores.GuildStore,i=valenced.discord.flux.Stores.MessageStore,a=e??t?.getChannelId?.();if(!a)return{messages:[],channelName:`Chat`};var o=i?.getMessages?.(a),s=o?.toArray?.()??o?._array??[],c=n?.getChannel?.(a),l=c?.guild_id?r?.getGuild?.(c.guild_id):void 0,u=l?.id&&l?.icon?`https://cdn.discordapp.com/icons/${l.id}/${l.icon}.png?size=128`:void 0;return{messages:s,channelName:c?.name??`Direct Message`,guildName:l?.name,guildIconUrl:u,topic:c?.topic}}async function w(e,t,n,r,i){var a=valenced.discord.flux.Stores.SelectedChannelStore,o=e??a?.getChannelId?.();if(!o)_(`No active channel found.`,`critical`);else{var s;if(typeof t==`number`&&t>0)s=await S(o,t);else{var{messages:c}=C(o);s=c}if(s.length===0)_(`No loaded messages found in this channel.`,`default`);else{var l=s;typeof t==`number`&&t>0&&t<s.length&&(l=s.slice(-t));var{channelName:u,guildName:d,guildIconUrl:f,topic:p}=C(o),m=u.replace(/[^a-zA-Z0-9_-]/g,`_`),h=n.format===`html`?`html`:n.format===`json`?`json`:`txt`,v=`discord_${m}_${Date.now()}.${h}`,y=i?.trim()||v,x={id:o,name:u,guildName:d,guildIconUrl:f,topic:p,totalMessages:l.length,exportedAt:(/* @__PURE__ */ new Date()).toISOString(),rangeDescription:typeof t==`number`?`Last ${l.length} message(s)`:`All ${l.length} message(s)`};await b(g(l,n,x),r,y)}}}async function T(e,t,n,r,i,a,o){var s=valenced.discord.flux.Stores.SelectedChannelStore,c=e??t.channel_id??s?.getChannelId?.();if(!c)_(`No active channel found.`,`critical`);else{var{channelName:l,guildName:u,guildIconUrl:d,topic:f}=C(c),p=valenced.discord.flux.Stores.MessageStore,m,h;if(n===`before`){var v=p?.getMessages?.(c),y=v?.toArray?.()??v?._array??[],x=y.findIndex(function(e){return e.id===t.id});if(typeof r==`number`&&r>0){var w=x===-1?y.length:x+1;if(w<r&&v?.hasMoreBefore){var T=r-w;m=await S(c,y.length+T,`before`)}else m=y}else m=r===`all`?await S(c,Math.max(500,y.length+50),`before`):y;var E=m.findIndex(function(e){return e.id===t.id}),D=E===-1?m.length:E+1;h=typeof r==`number`&&r>0&&r<D?m.slice(D-r,D):m.slice(0,D)}else{var O=p?.getMessages?.(c),k=O?.toArray?.()??O?._array??[],A=k.findIndex(function(e){return e.id===t.id});if(typeof r==`number`&&r>0){var j=A===-1?k.length:k.length-A;if(j<r&&O?.hasMoreAfter){var M=r-j;m=await S(c,k.length+M,`after`)}else m=k}else m=k;var N=m.findIndex(function(e){return e.id===t.id}),P=N===-1?0:N;h=typeof r==`number`&&r>0?m.slice(P,P+r):m.slice(P)}if(h.length===0)_(`No messages matched the export range.`,`default`);else{var F=l.replace(/[^a-zA-Z0-9_-]/g,`_`),I=i.format===`html`?`html`:i.format===`json`?`json`:`txt`,L=`discord_${F}_${n}_${t.id}.${I}`,R=o?.trim()||L,z={id:c,name:l,guildName:u,guildIconUrl:d,topic:f,totalMessages:h.length,exportedAt:(/* @__PURE__ */ new Date()).toISOString(),rangeDescription:n===`before`?`Exported ${h.length} message(s) before message ${t.id}`:`Exported ${h.length} message(s) after message ${t.id}`};await b(g(h,i,z),a,R)}}}function E({alertKey:e=`valenced-export-dialog`,initialMessage:n,initialChannelId:r,settings:i}){valenced.discord.actions.AlertActionCreators.openAlert(e,/*#__PURE__*/ (0,t.jsx)(D,{alertKey:e,initialMessage:n,initialChannelId:r,settings:i}))}function D({alertKey:e,initialMessage:n,initialChannelId:r,settings:i}){var a=v(),[o,s]=valenced.react.React.useState(n?`message`:`channel`),[c,l]=valenced.react.React.useState(i.format??`html`),[u,d]=valenced.react.React.useState(a?i.destination??`saf`:`share`),{messages:f,channelName:p}=C(r??n?.channel_id),m=p.replace(/[^a-zA-Z0-9_-]/g,`_`),[h,g]=valenced.react.React.useState(`all`),_=c===`html`?`html`:c===`json`?`json`:`txt`,y=o===`message`?`discord_msg_${n?.id??Date.now()}`:o===`before`?`discord_${m}_before_${n?.id??Date.now()}`:o===`after`?`discord_${m}_after_${n?.id??Date.now()}`:`discord_${m}_${Date.now()}`,[b,S]=valenced.react.React.useState(`${y}.${_}`);return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.AlertModal,{title:`Export Chat`,content:`Customize your export options below:`,extraContent:/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.ScrollView,{style:{maxHeight:380},showsVerticalScrollIndicator:!1,children:/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{gap:12,paddingVertical:4},children:[n&&/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRadioGroup,{title:`Export Target`,value:o,onChange:function(e){s(e);var t=`discord_${m}_${Date.now()}`;e===`message`?t=`discord_msg_${n.id}`:e===`before`?t=`discord_${m}_before_${n.id}`:e===`after`&&(t=`discord_${m}_after_${n.id}`),S(`${t}.${_}`)},children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`This Message Only`,subLabel:`Export only the selected message.`,value:`message`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`From Selected Message Backwards`,subLabel:`Export from this message back into older history.`,value:`before`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`From Selected Message Forwards`,subLabel:`Export from this message forward into newer history.`,value:`after`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Channel Chat History`,subLabel:`Export history from #${p} (${f.length} messages loaded).`,value:`channel`})]}),o!==`message`&&/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRowGroup,{title:`Message Count`,children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableSwitchRow,{label:o===`before`?`Export All Older Messages`:o===`after`?`Export All Newer Messages`:`Export All Loaded Messages`,subLabel:o===`before`?`Exports all available messages before this message.`:o===`after`?`Exports all available messages after this message.`:`Exports all ${f.length} currently loaded messages.`,value:h===`all`,onValueChange:function(e){g(e?`all`:`50`)}}),h!==`all`&&/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{paddingHorizontal:16,paddingVertical:8},children:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TextInput,{label:`Target Message Count`,placeholder:`e.g. 50, 100, 200 (fetches more if needed)`,value:h,onChange:function(e){g(e.replace(/[^0-9]/g,``))}})})]}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRadioGroup,{title:`Export Format`,value:c,onChange:function(e){l(e);var t=e===`html`?`html`:e===`json`?`json`:`txt`;S(function(e){var n=e.lastIndexOf(`.`);return n===-1?`${e}.${t}`:`${e.slice(0,n)}.${t}`})},children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Discord HTML (Recommended)`,subLabel:`Standalone offline chat viewer with avatars, markdown, attachments, and search.`,value:`html`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`JSON`,subLabel:`Structured data with raw message objects.`,value:`json`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Plain Text`,subLabel:`Simple formatted text transcript.`,value:`text`})]}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRadioGroup,{title:`Save Destination`,value:u,onChange:function(e){return d(e)},children:[a&&/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Save to Device (SAF)`,subLabel:`Opens Android document picker to choose folder and custom file name.`,value:`saf`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`System Share Sheet`,subLabel:`Share to other apps (Drive, Telegram, etc.).`,value:`share`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Copy to Clipboard`,subLabel:`Copies output directly to clipboard.`,value:`clipboard`})]}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRowGroup,{title:`File Name`,children:/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.View,{style:{paddingHorizontal:16,paddingVertical:8},children:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TextInput,{label:`Output File Name`,placeholder:`e.g. discord_chat.html`,value:b,onChange:function(e){return S(e)}})})})]})}),actions:/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.AlertActionButton,{text:`Export`,variant:`primary`,onPress:function(){valenced.discord.actions.AlertActionCreators.dismissAlert(e);var t={...i,format:c,destination:u};if(o===`message`&&n)x(n,t,u,b);else{var a=h===`all`?`all`:Math.max(1,Number.parseInt(h,10)||f.length);(o===`before`||o===`after`)&&n?T(r??n.channel_id,n,o,a,t,u,b):w(r??n?.channel_id,a,t,u,b)}}}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.AlertActionButton,{text:`Cancel`,onPress:function(){return valenced.discord.actions.AlertActionCreators.dismissAlert(e)}})]})})}var O={destination:`saf`,format:`html`,includeAttachments:!0,includeEmbeds:!0,includeTimestamps:!0};function k(e){if(typeof e!=`object`||!e||!(`props`in e))return!1;var t=e.props;if(typeof t!=`object`||!t)return!1;var n=t,r=typeof n.label==`string`||typeof n.message==`string`,i=typeof n.onPress==`function`||typeof n.onPressRow==`function`;return r&&i}function A(e,t=0){if(!(typeof e!=`object`||!e||t>15)){if(Array.isArray(e))for(var n of e){var r=A(n,t+1);if(r)return r}else if(`props`in e){var i=e.props;if(typeof i==`object`&&i){var a=i,o=a.children;if(Array.isArray(o)){if(o.some(k))return o;for(var s of o){var c=A(s,t+1);if(c)return c}}else if(o){if(k(o)){var l=[o];return a.children=l,l}return A(o,t+1)}}}}}var j=`hieuxyz-export-chat-row`;function M(e,t){var n,r=valenced.patcher.before(valenced.discord.actions.ActionSheetActionCreators,`openLazy`,function(r){var[i,a,o]=r;if(a!==`MessageLongPressActionSheet`&&a!==`MessageActionSheet`)return r;var s=o,c=s?.message;return c?.id&&i.then(function(r){if(typeof r==`object`&&r&&`default`in r){var i=r;if(typeof i.default==`function`){n?.();var a=valenced.patcher.after(i,`default`,function(e){if(!e)return e;var n=A(e);if(!n||n.some(function(e){return typeof e==`object`&&!!e&&`key`in e&&e.key===j}))return e;var r=n.find(k);if(!r)return e;var i={...O,...t.cache},a=c.channel_id??s?.channel?.id,o=function(e,t,n,i){var a=r.props.onPressRow?{key:e,message:t,onPressRow:n,icon:i}:{key:e,label:t,onPress:n,icon:i};return valenced.react.React.createElement(r.type,a)},l=r.type.Icon??valenced.discord.design.Design.ActionSheetRow?.Icon,u=valenced.utils.discord.lookupGeneratedIconComponent(`ShareIcon`,`DownloadIcon`,`ChatIcon`),d;if(l){if(u)d=valenced.react.React.createElement(l,{IconComponent:u});else try{var f=valenced.assets.getAssetIdByName(`ShareIcon`)??valenced.assets.getAssetIdByName(`DownloadIcon`)??valenced.assets.getAssetIdByName(`ic_share`);f!==void 0&&(d=valenced.react.React.createElement(l,{source:f}))}catch{}}var p=Math.min(1,n.length),m=o(j,`Export Chat`,function(){valenced.discord.actions.ActionSheetActionCreators.hideActionSheet(),E({alertKey:`valenced-export-chat-dialog`,initialMessage:c,initialChannelId:a,settings:i})},d);return n.splice(p,0,m),e});n=a,e(a)}}}),r});e(function(){r(),n?.(),n=void 0})}function N({api:e}){var n=e.jsonStorage,r=n.use(),i=v(),a={...O,destination:i?`saf`:`share`,...r};return/*#__PURE__*/ (0,t.jsx)(valenced.components.Page,{children:/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.ScrollView,{showsVerticalScrollIndicator:!1,contentContainerStyle:{paddingBottom:32},children:/*#__PURE__*/ (0,t.jsxs)(valenced.react.ReactNative.View,{style:{gap:8},children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRowGroup,{title:`Quick Actions`,children:/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRow,{label:`Export Active Channel...`,subLabel:`Open export dialog to customize format, count, file name, and destination for current channel.`,trailing:/*#__PURE__*/ (0,t.jsx)(valenced.components.TableRowAssetIcon,{name:`ChatIcon`}),onPress:function(){var e=valenced.discord.flux.Stores.SelectedChannelStore?.getChannelId?.();E({alertKey:`valenced-settings-export-dialog`,initialChannelId:e,settings:a})}})}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRadioGroup,{title:`Default Export Format`,value:a.format,onChange:function(e){n.set({format:e})},children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Discord HTML (Recommended)`,subLabel:`Standalone offline chat viewer with avatars, markdown, attachments, and live search.`,value:`html`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Structured JSON`,subLabel:`Machine-readable JSON data with complete message objects.`,value:`json`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Plain Text`,subLabel:`Simple formatted text transcript.`,value:`text`})]}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRadioGroup,{title:`Default Destination`,value:!i&&a.destination===`saf`?`share`:a.destination,onChange:function(e){n.set({destination:e})},children:[i&&/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Save to Device (SAF)`,subLabel:`Opens Android document picker to choose folder and custom file name (requires Hieuxyz Lib).`,value:`saf`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`System Share Sheet`,subLabel:`Share to other apps (Drive, Telegram, file managers, etc.).`,value:`share`}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableRadioRow,{label:`Copy to Clipboard`,subLabel:`Directly copies exported content to your clipboard.`,value:`clipboard`})]}),/*#__PURE__*/ (0,t.jsxs)(valenced.discord.design.Design.TableRowGroup,{title:`Content Options`,children:[/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableSwitchRow,{label:`Include Timestamps`,subLabel:`Include message creation timestamps.`,value:a.includeTimestamps,onValueChange:function(e){n.set({includeTimestamps:e})}}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableSwitchRow,{label:`Include Attachments`,subLabel:`Render image, video, audio, and file attachment cards.`,value:a.includeAttachments,onValueChange:function(e){n.set({includeAttachments:e})}}),/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.TableSwitchRow,{label:`Include Embeds`,subLabel:`Render rich embeds with titles, descriptions, and fields.`,value:a.includeEmbeds,onValueChange:function(e){n.set({includeEmbeds:e})}})]})]})})})}return e.default=plugin({jsonStorage:{load:!0,default:O},start({cleanup:e,jsonStorage:t}){M(e,t)},SettingsComponent:N}),e})({},valenced.react.ReactJSXRuntime);